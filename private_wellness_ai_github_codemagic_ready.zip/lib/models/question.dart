class WellnessQuestion {
  final String id;
  final String question;
  final String category;
  final String answerType;
  final String answerRequirement;
  final bool aiEstimateEligible;
  final bool especiallySensitive;
  final bool preferNotToAnswer;
  final List<String> units;
  final String helpText;
  final Map<String, dynamic> branching;

  const WellnessQuestion({
    required this.id,
    required this.question,
    required this.category,
    required this.answerType,
    required this.answerRequirement,
    required this.aiEstimateEligible,
    required this.especiallySensitive,
    required this.preferNotToAnswer,
    required this.units,
    required this.helpText,
    required this.branching,
  });

  factory WellnessQuestion.fromJson(Map<String, dynamic> json) => WellnessQuestion(
    id: json['id'] as String,
    question: json['question'] as String,
    category: json['category'] as String,
    answerType: json['answer_type'] as String,
    answerRequirement: json['answer_requirement'] as String,
    aiEstimateEligible: json['ai_estimate_eligible'] as bool? ?? false,
    especiallySensitive: json['especially_sensitive'] as bool? ?? false,
    preferNotToAnswer: json['prefer_not_to_answer'] as bool? ?? false,
    units: (json['units'] as List<dynamic>? ?? const []).map((e) => e.toString()).toList(),
    helpText: json['help_text'] as String? ?? '',
    branching: Map<String, dynamic>.from(json['branching'] as Map? ?? const {}),
  );
}

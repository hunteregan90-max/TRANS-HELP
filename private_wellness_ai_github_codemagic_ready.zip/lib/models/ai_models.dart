import 'dart:convert';

enum AiProviderKind { openai, openrouter, groq, poe, customOpenAiCompatible }

enum AiReasoningLevel { minimum, medium, high, xHigh, maximum }

extension AiProviderKindX on AiProviderKind {
  String get label => switch (this) {
        AiProviderKind.openai => 'OpenAI',
        AiProviderKind.openrouter => 'OpenRouter',
        AiProviderKind.groq => 'Groq',
        AiProviderKind.poe => 'Poe',
        AiProviderKind.customOpenAiCompatible => 'Custom OpenAI-compatible',
      };

  String get defaultBaseUrl => switch (this) {
        AiProviderKind.openai => 'https://api.openai.com/v1',
        AiProviderKind.openrouter => 'https://openrouter.ai/api/v1',
        AiProviderKind.groq => 'https://api.groq.com/openai/v1',
        AiProviderKind.poe => 'https://api.poe.com/v1',
        AiProviderKind.customOpenAiCompatible => '',
      };
}

extension AiReasoningLevelX on AiReasoningLevel {
  String get label => switch (this) {
        AiReasoningLevel.minimum => 'Minimum',
        AiReasoningLevel.medium => 'Medium',
        AiReasoningLevel.high => 'High',
        AiReasoningLevel.xHigh => 'X-High',
        AiReasoningLevel.maximum => 'Maximum',
      };

  String get apiValue => switch (this) {
        AiReasoningLevel.minimum => 'low',
        AiReasoningLevel.medium => 'medium',
        AiReasoningLevel.high => 'high',
        AiReasoningLevel.xHigh => 'xhigh',
        AiReasoningLevel.maximum => 'max',
      };
}

class AiSettings {
  const AiSettings({
    this.enabled = false,
    this.provider = AiProviderKind.openai,
    this.model = '',
    this.reasoning = AiReasoningLevel.medium,
    this.customBaseUrl = '',
    this.externalProcessingConsent = false,
    this.fullContext = false,
    this.includeSensitiveMentalHealth = false,
    this.includeSexualReproductive = false,
    this.includeJournals = false,
    this.includeContacts = false,
    this.includeSafetyPlan = false,
    this.includePhotoMetadata = false,
    this.includeCommunityHistory = false,
    this.allowActionDrafts = false,
    this.autoInsights = false,
    this.consentAcceptedAt,
  });

  final bool enabled;
  final AiProviderKind provider;
  final String model;
  final AiReasoningLevel reasoning;
  final String customBaseUrl;
  final bool externalProcessingConsent;
  final bool fullContext;
  final bool includeSensitiveMentalHealth;
  final bool includeSexualReproductive;
  final bool includeJournals;
  final bool includeContacts;
  final bool includeSafetyPlan;
  final bool includePhotoMetadata;
  final bool includeCommunityHistory;
  final bool allowActionDrafts;
  final bool autoInsights;
  final String? consentAcceptedAt;

  String get baseUrl {
    final value = customBaseUrl.trim();
    if (provider == AiProviderKind.customOpenAiCompatible && value.isNotEmpty) {
      return value.endsWith('/') ? value.substring(0, value.length - 1) : value;
    }
    return provider.defaultBaseUrl;
  }

  bool get ready => enabled && externalProcessingConsent && model.trim().isNotEmpty && baseUrl.isNotEmpty;

  AiSettings copyWith({
    bool? enabled,
    AiProviderKind? provider,
    String? model,
    AiReasoningLevel? reasoning,
    String? customBaseUrl,
    bool? externalProcessingConsent,
    bool? fullContext,
    bool? includeSensitiveMentalHealth,
    bool? includeSexualReproductive,
    bool? includeJournals,
    bool? includeContacts,
    bool? includeSafetyPlan,
    bool? includePhotoMetadata,
    bool? includeCommunityHistory,
    bool? allowActionDrafts,
    bool? autoInsights,
    String? consentAcceptedAt,
  }) =>
      AiSettings(
        enabled: enabled ?? this.enabled,
        provider: provider ?? this.provider,
        model: model ?? this.model,
        reasoning: reasoning ?? this.reasoning,
        customBaseUrl: customBaseUrl ?? this.customBaseUrl,
        externalProcessingConsent: externalProcessingConsent ?? this.externalProcessingConsent,
        fullContext: fullContext ?? this.fullContext,
        includeSensitiveMentalHealth: includeSensitiveMentalHealth ?? this.includeSensitiveMentalHealth,
        includeSexualReproductive: includeSexualReproductive ?? this.includeSexualReproductive,
        includeJournals: includeJournals ?? this.includeJournals,
        includeContacts: includeContacts ?? this.includeContacts,
        includeSafetyPlan: includeSafetyPlan ?? this.includeSafetyPlan,
        includePhotoMetadata: includePhotoMetadata ?? this.includePhotoMetadata,
        includeCommunityHistory: includeCommunityHistory ?? this.includeCommunityHistory,
        allowActionDrafts: allowActionDrafts ?? this.allowActionDrafts,
        autoInsights: autoInsights ?? this.autoInsights,
        consentAcceptedAt: consentAcceptedAt ?? this.consentAcceptedAt,
      );

  Map<String, dynamic> toJson() => {
        'enabled': enabled,
        'provider': provider.name,
        'model': model,
        'reasoning': reasoning.name,
        'custom_base_url': customBaseUrl,
        'external_processing_consent': externalProcessingConsent,
        'full_context': fullContext,
        'include_sensitive_mental_health': includeSensitiveMentalHealth,
        'include_sexual_reproductive': includeSexualReproductive,
        'include_journals': includeJournals,
        'include_contacts': includeContacts,
        'include_safety_plan': includeSafetyPlan,
        'include_photo_metadata': includePhotoMetadata,
        'include_community_history': includeCommunityHistory,
        'allow_action_drafts': allowActionDrafts,
        'auto_insights': autoInsights,
        'consent_accepted_at': consentAcceptedAt,
      };

  factory AiSettings.fromJson(Map<String, dynamic> json) {
    T byName<T extends Enum>(Iterable<T> values, String? name, T fallback) {
      if (name == null) return fallback;
      for (final value in values) {
        if (value.name == name) return value;
      }
      return fallback;
    }

    return AiSettings(
      enabled: json['enabled'] == true,
      provider: byName(AiProviderKind.values, json['provider'] as String?, AiProviderKind.openai),
      model: '${json['model'] ?? ''}',
      reasoning: byName(AiReasoningLevel.values, json['reasoning'] as String?, AiReasoningLevel.medium),
      customBaseUrl: '${json['custom_base_url'] ?? ''}',
      externalProcessingConsent: json['external_processing_consent'] == true,
      fullContext: json['full_context'] == true,
      includeSensitiveMentalHealth: json['include_sensitive_mental_health'] == true,
      includeSexualReproductive: json['include_sexual_reproductive'] == true,
      includeJournals: json['include_journals'] == true,
      includeContacts: json['include_contacts'] == true,
      includeSafetyPlan: json['include_safety_plan'] == true,
      includePhotoMetadata: json['include_photo_metadata'] == true,
      includeCommunityHistory: json['include_community_history'] == true,
      allowActionDrafts: json['allow_action_drafts'] == true,
      autoInsights: json['auto_insights'] == true,
      consentAcceptedAt: json['consent_accepted_at'] as String?,
    );
  }
}

class AiAppAction {
  const AiAppAction({required this.type, required this.payload});
  final String type;
  final Map<String, dynamic> payload;

  factory AiAppAction.fromJson(Map<String, dynamic> json) => AiAppAction(
        type: '${json['type'] ?? ''}',
        payload: Map<String, dynamic>.from(json['payload'] as Map? ?? const <String, dynamic>{}),
      );
}

class AiCallResult {
  const AiCallResult({
    required this.text,
    required this.provider,
    required this.model,
    required this.requestedReasoning,
    required this.effectiveReasoning,
    required this.actions,
    this.usage,
    this.warning,
  });

  final String text;
  final AiProviderKind provider;
  final String model;
  final AiReasoningLevel requestedReasoning;
  final String effectiveReasoning;
  final List<AiAppAction> actions;
  final Map<String, dynamic>? usage;
  final String? warning;
}

class AiProjectionPoint {
  const AiProjectionPoint({required this.month, required this.value, required this.low, required this.high});
  final int month;
  final double value;
  final double low;
  final double high;

  Map<String, dynamic> toJson() => {'month': month, 'value': value, 'low': low, 'high': high};
}

String prettyJson(Object? value) => const JsonEncoder.withIndent('  ').convert(value);

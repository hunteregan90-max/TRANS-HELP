import 'package:flutter/material.dart';
import '../services/secure_vault.dart';

class JournalsScreen extends StatefulWidget { const JournalsScreen({super.key,required this.vault}); final SecureVault vault; @override State<JournalsScreen> createState()=>_JournalsScreenState(); }
class _JournalsScreenState extends State<JournalsScreen>{
 static const kinds=['Daily','Mood','Trauma','Transition','HRT','Body change','Dysphoria','Euphoria','Dream/nightmare','Trigger','Dissociation','Grounding','Therapy','Medication','Private free-write'];
 String kind='Daily'; final text=TextEditingController(), tags=TextEditingController(); List<Map<String,dynamic>> entries=[];
 @override void initState(){super.initState();_load();} @override void dispose(){text.dispose();tags.dispose();super.dispose();}
 Future<void> _load()async{final raw=await widget.vault.readValue('journals',fallback:const []);if(!mounted)return;setState(()=>entries=List<Map<String,dynamic>>.from((raw as List).map((e)=>Map<String,dynamic>.from(e as Map))));}
 Future<void> _save()async{if(text.text.trim().isEmpty)return;await widget.vault.appendToCollection('journals',{'id':DateTime.now().microsecondsSinceEpoch.toString(),'type':kind,'text':text.text.trim(),'tags':tags.text.split(',').map((e)=>e.trim()).where((e)=>e.isNotEmpty).toList(),'created_at':DateTime.now().toUtc().toIso8601String(),'ai_summary_opt_in':false});text.clear();tags.clear();await _load();}
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Private Journals')),body:ListView(padding:const EdgeInsets.all(16),children:[
  DropdownButtonFormField<String>(value:kind,decoration:const InputDecoration(labelText:'Journal type'),items:kinds.map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>kind=v!)),const SizedBox(height:12),
  TextField(controller:text,minLines:5,maxLines:12,decoration:const InputDecoration(labelText:'Entry',alignLabelWithHint:true)),const SizedBox(height:12),TextField(controller:tags,decoration:const InputDecoration(labelText:'Tags (comma separated)')),const SizedBox(height:12),FilledButton.icon(onPressed:_save,icon:const Icon(Icons.lock),label:const Text('Save encrypted entry')),const Divider(height:32),
  ...entries.take(40).map((e)=>Card(child:ListTile(title:Text('${e['type']}'),subtitle:Text('${e['text']}',maxLines:4,overflow:TextOverflow.ellipsis),trailing:Text('${(e['tags'] as List?)?.length??0} tags')))),
 ]));
}

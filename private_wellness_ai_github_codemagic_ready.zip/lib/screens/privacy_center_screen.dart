import 'package:flutter/material.dart';
import '../services/secure_vault.dart';
import '../services/ai_provider_service.dart';

class PrivacyCenterScreen extends StatefulWidget {
  const PrivacyCenterScreen({super.key, required this.vault});
  final SecureVault vault;
  @override
  State<PrivacyCenterScreen> createState() => _PrivacyCenterScreenState();
}

class _PrivacyCenterScreenState extends State<PrivacyCenterScreen> {
  String? exportPath;
  Map<String, int> counts = {};
  bool aiMemoryEnabled = false;
  int aiMemoryItems = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final out = <String, int>{};
    for (final k in ['answers', 'measurements', 'journals', 'contacts', 'mental_checkins', 'photos', 'ai_analysis_history']) {
      out[k] = await widget.vault.itemCount(k);
    }
    final enabled = await widget.vault.readValue('ai_memory_enabled', fallback: false) == true;
    final memoryCount = await widget.vault.itemCount('ai_memory');
    if (mounted) {
      setState(() {
        counts = out;
        aiMemoryEnabled = enabled;
        aiMemoryItems = memoryCount;
      });
    }
  }

  Future<void> _exportJson() async {
    final path = await widget.vault.exportDecryptedJson();
    if (mounted) setState(() => exportPath = path);
  }

  Future<void> _exportCsv() async {
    final path = await widget.vault.exportDecryptedCsv();
    if (mounted) setState(() => exportPath = path);
  }

  Future<void> _setAiMemory(bool value) async {
    await widget.vault.writeValue('ai_memory_enabled', value);
    if (mounted) setState(() => aiMemoryEnabled = value);
  }

  Future<void> _clearAiMemory() async {
    await widget.vault.writeValue('ai_memory', <Map<String, dynamic>>[]);
    await _load();
  }

  Future<void> _clear() async {
    final ok = await showDialog<bool>(
          context: context,
          builder: (c) => AlertDialog(
            title: const Text('Delete local private data?'),
            content: const Text(
              'This deletes the encrypted local vault, encrypted progress-photo blobs, and the local vault encryption key from this device. This action cannot be undone from inside the app.',
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
              FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete')),
            ],
          ),
        ) ??
        false;
    if (ok) {
      await widget.vault.clear();
      await const AiCredentialStore().clearAll();
      exportPath = null;
      await _load();
    }
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('Privacy Center')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Card(
              child: ListTile(
                leading: Icon(Icons.lock),
                title: Text('Private by default'),
                subtitle: Text(
                  'Health answers, journals, contacts, measurements, check-ins and progress photos are kept in encrypted local storage. Social data is sent only when you intentionally use the community backend.',
                ),
              ),
            ),
            for (final e in counts.entries)
              ListTile(title: Text(e.key.replaceAll('_', ' ')), trailing: Text('${e.value} items')),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.data_object),
              title: const Text('Export local data as JSON'),
              subtitle: const Text('Creates a readable JSON export. Protect exported copies carefully.'),
              onTap: _exportJson,
            ),
            ListTile(
              leading: const Icon(Icons.table_view_outlined),
              title: const Text('Export local data as CSV'),
              subtitle: const Text('Creates a readable CSV export for spreadsheet analysis. Protect exported copies carefully.'),
              onTap: _exportCsv,
            ),
            if (exportPath != null) SelectableText('Export created at:\n$exportPath'),
            const Divider(),
            SwitchListTile(
              secondary: const Icon(Icons.memory),
              title: const Text('Enable user-controlled AI memory'),
              subtitle: Text(
                aiMemoryEnabled
                    ? 'Enabled. The companion still remembers a message only when you explicitly select “Remember this message.”'
                    : 'Disabled. The wellness companion cannot add new items to AI memory.',
              ),
              value: aiMemoryEnabled,
              onChanged: _setAiMemory,
            ),
            ListTile(
              title: const Text('Remembered items'),
              subtitle: Text('$aiMemoryItems saved items · community posts are never added automatically'),
              trailing: TextButton(onPressed: aiMemoryItems == 0 ? null : _clearAiMemory, child: const Text('Clear')),
            ),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.delete_forever),
              title: const Text('Delete local vault'),
              subtitle: const Text('Removes locally stored wellness data, encrypted photos, AI memory, saved AI provider keys, and the local encryption key'),
              onTap: _clear,
            ),
          ],
        ),
      );
}

import 'package:flutter/material.dart';
import '../models/ai_models.dart';
import '../models/question.dart';
import '../services/ai_context_builder.dart';
import '../services/ai_provider_service.dart';
import '../services/secure_vault.dart';
import 'crisis_mode_screen.dart';

class CompanionScreen extends StatefulWidget {
  const CompanionScreen({super.key, required this.vault, required this.questions});
  final SecureVault vault;
  final Map<String, List<WellnessQuestion>> questions;
  @override
  State<CompanionScreen> createState() => _CompanionScreenState();
}

class _CompanionScreenState extends State<CompanionScreen> {
  final input = TextEditingController();
  final List<Map<String, String>> turns = [];
  final providerService = AiProviderService();
  final credentials = const AiCredentialStore();
  bool aiMemoryEnabled = false;
  bool rememberThis = false;
  bool busy = false;
  AiSettings settings = const AiSettings();

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final rawHistory = await widget.vault.readValue('companion_history', fallback: const []);
    final enabled = await widget.vault.readValue('ai_memory_enabled', fallback: false) == true;
    final rawSettings = await widget.vault.readValue('ai_settings', fallback: const <String, dynamic>{});
    if (mounted) {
      setState(() {
        turns
          ..clear()
          ..addAll((rawHistory as List).map((e) => Map<String, String>.from(e as Map)));
        aiMemoryEnabled = enabled;
        settings = AiSettings.fromJson(Map<String, dynamic>.from(rawSettings as Map));
      });
    }
  }

  @override
  void dispose() {
    input.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final text = input.text.trim();
    if (text.isEmpty || busy) return;
    input.clear();
    setState(() => busy = true);
    String reply;
    final lower = text.toLowerCase();

    if (_looksLikeImmediateSafetyConcern(lower)) {
      reply = 'Your safety is more important than continuing an ordinary AI conversation. If you may act on suicidal or self-harm thoughts, are in immediate danger, or cannot stay safe, seek immediate in-person help or emergency services where you are. Open Crisis Mode for your saved safety plan and trusted contacts.';
    } else if (settings.ready) {
      try {
        final apiKey = await credentials.read(settings.provider);
        final context = await AiContextBuilder(widget.questions).build(widget.vault, settings);
        final result = await providerService.generate(
          settings: settings,
          apiKey: apiKey,
          userPrompt: '''
CURRENT USER MESSAGE:
$text

CONSENTED APP CONTEXT:
$context

Respond as an integrated wellness companion. Use the supplied app data when relevant and distinguish data from inference. Do not diagnose. Do not recommend medication-dose changes. For transition outcomes, give uncertainty rather than guarantees.
''',
          instructions: '''You are the trauma-informed AI companion inside Private Wellness. Help organize thoughts, recognize user-reported patterns, suggest grounding and coping options, prepare clinician questions, and explain transition tracking. Do not diagnose DID/PTSD/bipolar/personality disorders, reinforce delusions, create alters, provide self-harm instructions, advise medication discontinuation, or claim body/fertility/surgery outcomes are guaranteed. If immediate danger is suggested, prioritize emergency/in-person support and the user's safety plan.''',
          maxOutputTokens: 2500,
        );
        reply = result.warning == null ? result.text : '${result.text}\n\nProvider note: ${result.warning}';
      } catch (e) {
        reply = 'The configured external AI could not answer: $e\n\n${_localFallback(lower)}';
      }
    } else {
      reply = _localFallback(lower);
    }

    final shouldRemember = aiMemoryEnabled && rememberThis;
    if (mounted) {
      setState(() {
        turns.insertAll(0, [
          {'role': 'assistant', 'text': reply},
          {'role': 'user', 'text': text},
        ]);
        rememberThis = false;
        busy = false;
      });
    }
    await widget.vault.writeValue('companion_history', turns.take(100).toList());
    if (shouldRemember) {
      await widget.vault.appendToCollection('ai_memory', {
        'created_at': DateTime.now().toUtc().toIso8601String(),
        'source': 'wellness_companion',
        'text': text,
      });
    }
  }

  bool _looksLikeImmediateSafetyConcern(String lower) =>
      lower.contains('kill myself') ||
      lower.contains('suicide') ||
      lower.contains('hurt myself') ||
      lower.contains('self harm') ||
      lower.contains('self-harm') ||
      lower.contains('not safe right now');

  String _localFallback(String lower) {
    if (lower.contains('dissociat') || lower.contains('unreal') || lower.contains('spacing out')) {
      return 'You could note what was happening just before the disconnection, how long it seemed to last, and what helped you feel more oriented afterward. I will not diagnose DID or another condition from this description. If grounding feels useful, choose a gentle present-focused sensory cue rather than forcing yourself through distress.';
    }
    if (lower.contains('hrt') || lower.contains('testosterone') || lower.contains('estradiol') || lower.contains('dose')) {
      return 'I can help organize what you noticed, when it happened relative to your prescribed schedule, and what you may want to ask your clinician. I will not recommend changing a medication dose from a trend or prediction.';
    }
    return 'A useful way to organize this may be: what happened, what you noticed in your body or emotions, what meaning you made of it, what helped or made it harder, and what kind of support you want next. Configure the Integrated AI Center if you want this companion to analyze your consented app data with your selected provider/model.';
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('Wellness Companion')),
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Card(
                child: ListTile(
                  leading: Icon(settings.ready ? Icons.hub_outlined : Icons.offline_bolt_outlined),
                  title: Text(settings.ready ? '${settings.provider.label} · ${settings.model}' : 'Local safety fallback'),
                  subtitle: Text(settings.ready
                      ? 'Uses the external AI configuration and data-sharing consent from Integrated AI Center.'
                      : 'No external AI is configured. This screen is using local safety-focused responses.'),
                ),
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                reverse: true,
                children: [
                  if (busy) const Align(alignment: Alignment.centerLeft, child: Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator())),
                  ...turns.map(
                    (t) => Align(
                      alignment: t['role'] == 'user' ? Alignment.centerRight : Alignment.centerLeft,
                      child: ConstrainedBox(
                        constraints: const BoxConstraints(maxWidth: 560),
                        child: Card(child: Padding(padding: const EdgeInsets.all(12), child: SelectableText(t['text'] ?? ''))),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            if (aiMemoryEnabled)
              CheckboxListTile(
                dense: true,
                value: rememberThis,
                onChanged: (v) => setState(() => rememberThis = v ?? false),
                title: const Text('Remember this message for companion memory'),
                subtitle: const Text('Off by default for every message. Community posts are never used as permission.'),
              ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  Expanded(child: TextField(controller: input, minLines: 1, maxLines: 5, decoration: const InputDecoration(hintText: 'Write what is on your mind…'))),
                  const SizedBox(width: 8),
                  IconButton.filled(onPressed: busy ? null : _send, icon: const Icon(Icons.send)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
              child: OutlinedButton.icon(
                onPressed: () => Navigator.push(c, MaterialPageRoute(builder: (_) => CrisisModeScreen(vault: widget.vault))),
                icon: const Icon(Icons.health_and_safety),
                label: const Text('Open Crisis Mode'),
              ),
            ),
          ],
        ),
      );
}

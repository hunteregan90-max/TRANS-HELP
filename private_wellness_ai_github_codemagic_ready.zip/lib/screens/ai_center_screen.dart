import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../models/ai_models.dart';
import '../models/question.dart';
import '../services/ai_context_builder.dart';
import '../services/ai_provider_service.dart';
import '../services/estimation_service.dart';
import '../services/secure_vault.dart';

class AiCenterScreen extends StatefulWidget {
  const AiCenterScreen({super.key, required this.vault, required this.questions});
  final SecureVault vault;
  final Map<String, List<WellnessQuestion>> questions;

  @override
  State<AiCenterScreen> createState() => _AiCenterScreenState();
}

class _AiCenterScreenState extends State<AiCenterScreen> {
  final providerService = AiProviderService();
  final credentials = const AiCredentialStore();
  final apiKey = TextEditingController();
  final customBase = TextEditingController();
  final prompt = TextEditingController();
  final manualModel = TextEditingController();
  AiSettings settings = const AiSettings();
  List<String> models = [];
  AiCallResult? result;
  bool loading = true;
  bool busy = false;
  String status = '';
  String metric = 'weight';
  double horizon = 12;
  double trendStrength = .65;
  List<AiProjectionPoint> projection = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    apiKey.dispose();
    customBase.dispose();
    prompt.dispose();
    manualModel.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    final raw = await widget.vault.readValue('ai_settings', fallback: const <String, dynamic>{});
    final loaded = AiSettings.fromJson(Map<String, dynamic>.from(raw as Map));
    final key = await credentials.read(loaded.provider);
    if (!mounted) return;
    setState(() {
      settings = loaded;
      apiKey.text = key;
      customBase.text = loaded.customBaseUrl;
      manualModel.text = loaded.model;
      loading = false;
    });
    await _buildProjection();
    await _maybeAutoInsight();
  }

  Future<void> _switchProvider(AiProviderKind provider) async {
    final key = await credentials.read(provider);
    if (!mounted) return;
    setState(() {
      settings = settings.copyWith(provider: provider, model: '', customBaseUrl: provider == AiProviderKind.customOpenAiCompatible ? customBase.text : '');
      apiKey.text = key;
      models = [];
      manualModel.clear();
      status = '';
    });
  }

  Future<void> _save({bool showMessage = true}) async {
    final model = manualModel.text.trim().isEmpty ? settings.model : manualModel.text.trim();
    var next = settings.copyWith(model: model, customBaseUrl: customBase.text.trim());
    if (next.externalProcessingConsent && next.consentAcceptedAt == null) {
      next = next.copyWith(consentAcceptedAt: DateTime.now().toUtc().toIso8601String());
    }
    await credentials.write(next.provider, apiKey.text);
    await widget.vault.writeValue('ai_settings', next.toJson());
    if (!mounted) return;
    setState(() => settings = next);
    if (showMessage) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('AI settings saved securely')));
  }

  Future<void> _loadModels() async {
    await _save(showMessage: false);
    if (apiKey.text.trim().isEmpty && settings.provider != AiProviderKind.poe) {
      setState(() => status = 'Enter and save an API key first.');
      return;
    }
    setState(() {
      busy = true;
      status = 'Loading models from ${settings.provider.label}…';
    });
    try {
      final list = await providerService.listModels(settings, apiKey.text.trim());
      if (!mounted) return;
      setState(() {
        models = list;
        status = list.isEmpty ? 'No model IDs were returned. You can still type a model ID manually.' : '${list.length} models available.';
        if (settings.model.isNotEmpty && list.contains(settings.model)) manualModel.text = settings.model;
      });
    } catch (e) {
      if (mounted) setState(() => status = '$e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _run(String request, {bool includeProjection = false}) async {
    await _save(showMessage: false);
    if (!settings.ready) {
      setState(() => status = 'Enable AI, accept external-processing consent, and select a model first.');
      return;
    }
    setState(() {
      busy = true;
      status = 'Building your consented app context…';
      result = null;
    });
    try {
      final context = await AiContextBuilder(widget.questions).build(widget.vault, settings);
      final chart = includeProjection && projection.isNotEmpty
          ? '\n\nCURRENT ADJUSTABLE PROJECTION CHART JSON:\n${prettyJson(projection.map((e) => e.toJson()).toList())}'
          : '';
      final userPrompt = '''
USER REQUEST:
$request

CONSENTED PRIVATE-WELLNESS APP CONTEXT:
$context
$chart

Use the app context directly when it is relevant. Clearly separate observed user data, mathematical trend extrapolation, and your own inference. Never invent a measurement or symptom that is absent. For body/transition projections, give plausible ranges and uncertainty rather than a guaranteed outcome.
''';
      final response = await providerService.generate(
        settings: settings,
        apiKey: apiKey.text.trim(),
        userPrompt: userPrompt,
        instructions: _systemInstructions(settings.allowActionDrafts),
      );
      await widget.vault.writeValue('last_ai_analysis_at', DateTime.now().toUtc().toIso8601String());
      await widget.vault.appendToCollection('ai_analysis_history', {
        'created_at': DateTime.now().toUtc().toIso8601String(),
        'provider': response.provider.label,
        'model': response.model,
        'requested_reasoning': response.requestedReasoning.label,
        'effective_reasoning': response.effectiveReasoning,
        'request': request,
        'response': response.text,
      });
      if (!mounted) return;
      setState(() {
        result = response;
        status = 'Completed with ${response.model} · effective reasoning: ${response.effectiveReasoning}';
      });
    } catch (e) {
      if (mounted) setState(() => status = '$e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  String _systemInstructions(bool actions) => '''
You are the AI analysis layer inside a private transition-wellness and trauma-informed tracking application. You may analyze the user-provided app context, identify patterns, explain trends, summarize journals, suggest questions for qualified clinicians, and help organize coping or safety-plan information.

Safety rules:
- Do not claim to diagnose PTSD, DID, bipolar disorder, personality disorders, or other conditions from app data.
- Do not recommend changing prescription doses or stopping medication. Medication-related observations should be framed as topics to discuss with a qualified clinician.
- Do not give self-harm or suicide instructions, concealment advice, or dangerous weight-control advice.
- If the supplied data or current request indicates possible immediate self-harm/suicide danger, prioritize immediate safety, trusted in-person support, emergency services where appropriate, and the user's existing safety plan over routine analysis.
- Do not reinforce delusions or manufacture identities/alters. Parts-language may be used neutrally when the user already uses it.
- For transition/body growth, fertility, surgery, or medical outcomes, state uncertainty and never claim a guaranteed final result.
- Treat all supplied data as extremely sensitive. Do not request additional intimate detail unless it is necessary to answer the user's request.
- Never expose hidden reasoning. Give concise conclusions, evidence from the user's data, uncertainty, and useful next steps.

${actions ? '''APP INTEGRATION: You may optionally propose user-approved app actions. Put ONLY safe drafts at the very end in this exact machine-readable form:
<app_actions>[{"type":"journal_draft","payload":{"title":"...","body":"...","journal_type":"daily journal"}},{"type":"goal_draft","payload":{"title":"...","notes":"..."}},{"type":"reminder_draft","payload":{"title":"...","notes":"...","reminder_type":"Appointment"}},{"type":"chart_adjustment","payload":{"metric":"hips","horizon_months":12,"trend_strength":0.6}}]</app_actions>
Never create medication-dose changes, emergency-contact actions, account changes, invitations, moderation actions, or destructive actions. The app will ask the user to approve every draft before saving it.''': 'Do not emit app_actions.'}
''';

  Future<void> _applyAction(AiAppAction action) async {
    if (action.type == 'journal_draft') {
      await widget.vault.appendToCollection('journals', {
        'id': DateTime.now().microsecondsSinceEpoch.toString(),
        'type': '${action.payload['journal_type'] ?? 'daily journal'}',
        'title': '${action.payload['title'] ?? 'AI-assisted draft'}',
        'text': '${action.payload['body'] ?? ''}',
        'tags': ['ai-assisted'],
        'created_at': DateTime.now().toUtc().toIso8601String(),
      });
    } else if (action.type == 'goal_draft') {
      await widget.vault.appendToCollection('tools', {
        'id': DateTime.now().microsecondsSinceEpoch.toString(),
        'type': 'Goal',
        'title': '${action.payload['title'] ?? 'AI-assisted goal'}',
        'notes': '${action.payload['notes'] ?? ''}',
        'done': false,
        'created_at': DateTime.now().toUtc().toIso8601String(),
      });
    } else if (action.type == 'reminder_draft') {
      await widget.vault.appendToCollection('tools', {
        'id': DateTime.now().microsecondsSinceEpoch.toString(),
        'type': '${action.payload['reminder_type'] ?? 'Task'}',
        'title': '${action.payload['title'] ?? 'AI-assisted reminder'}',
        'notes': '${action.payload['notes'] ?? ''}',
        'done': false,
        'created_at': DateTime.now().toUtc().toIso8601String(),
      });
    } else if (action.type == 'chart_adjustment') {
      const metrics = {'weight', 'waist', 'hips', 'chest', 'bust', 'underbust', 'shoulders', 'thighs', 'glutes'};
      final nextMetric = '${action.payload['metric'] ?? metric}';
      final nextHorizon = (action.payload['horizon_months'] as num?)?.toDouble() ?? horizon;
      final nextStrength = (action.payload['trend_strength'] as num?)?.toDouble() ?? trendStrength;
      if (mounted) {
        setState(() {
          if (metrics.contains(nextMetric)) metric = nextMetric;
          horizon = nextHorizon.clamp(3, 24).toDouble();
          trendStrength = nextStrength.clamp(0, 1).toDouble();
        });
      }
      await _buildProjection();
    } else {
      return;
    }
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${action.type.replaceAll('_', ' ')} saved after your approval.')));
  }

  Future<void> _buildProjection() async {
    final raw = await widget.vault.readValue('measurements', fallback: const []);
    final list = List<Map<String, dynamic>>.from((raw as List).map((e) => Map<String, dynamic>.from(e as Map)));
    final trend = EstimationService().trend(metric, list);
    if (trend == null) {
      if (mounted) setState(() => projection = []);
      return;
    }
    final months = horizon.round();
    final baseRate = trend.monthlyRate * trendStrength;
    final uncertainty = math.max(trend.current.abs() * .02, baseRate.abs() * .75 + .01);
    final points = <AiProjectionPoint>[];
    for (var month = 0; month <= months; month++) {
      final expected = trend.current + baseRate * month;
      final spread = uncertainty * math.sqrt(math.max(1, month));
      points.add(AiProjectionPoint(month: month, value: expected, low: expected - spread, high: expected + spread));
    }
    if (mounted) setState(() => projection = points);
  }

  Future<void> _maybeAutoInsight() async {
    if (!settings.ready || !settings.autoInsights) return;
    final changed = '${await widget.vault.readValue('_last_data_change_at', fallback: '')}';
    final analyzed = '${await widget.vault.readValue('last_ai_analysis_at', fallback: '')}';
    final changedAt = DateTime.tryParse(changed);
    final analyzedAt = DateTime.tryParse(analyzed);
    if (changedAt != null && (analyzedAt == null || changedAt.isAfter(analyzedAt))) {
      await _run('Review all newly available app data and give me the most important changes, patterns, uncertainty, and useful next steps. Keep medical conclusions cautious.');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: const Text('Integrated AI Center')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Card(
            child: ListTile(
              leading: Icon(Icons.privacy_tip_outlined),
              title: Text('External AI is optional and not private local processing'),
              subtitle: Text('When enabled, the app sends the data categories you consent to directly to your selected AI provider. Provider retention/logging, account security, legal access, or a provider breach can expose that data. API keys are stored separately and are never inserted into AI context or data exports.'),
            ),
          ),
          SwitchListTile(
            value: settings.enabled,
            onChanged: (v) => setState(() => settings = settings.copyWith(enabled: v)),
            title: const Text('Enable external AI integration'),
          ),
          CheckboxListTile(
            value: settings.externalProcessingConsent,
            onChanged: (v) => setState(() => settings = settings.copyWith(externalProcessingConsent: v ?? false, consentAcceptedAt: v == true ? DateTime.now().toUtc().toIso8601String() : null)),
            title: const Text('I understand and consent to external AI processing'),
            subtitle: const Text('I understand selected health/mental-health information leaves this device and may be retained, logged, leaked, or otherwise handled under the AI provider’s policies.'),
          ),
          const Divider(),
          DropdownButtonFormField<AiProviderKind>(
            value: settings.provider,
            decoration: const InputDecoration(labelText: 'AI provider'),
            items: AiProviderKind.values.map((p) => DropdownMenuItem(value: p, child: Text(p.label))).toList(),
            onChanged: busy ? null : (p) { if (p != null) _switchProvider(p); },
          ),
          const SizedBox(height: 10),
          if (settings.provider == AiProviderKind.customOpenAiCompatible) ...[
            TextField(controller: customBase, decoration: const InputDecoration(labelText: 'OpenAI-compatible base URL', hintText: 'https://provider.example/v1')),
            const SizedBox(height: 10),
          ],
          TextField(controller: apiKey, obscureText: true, autocorrect: false, enableSuggestions: false, decoration: InputDecoration(labelText: '${settings.provider.label} API key', helperText: 'Saved in platform secure storage; excluded from app exports and AI context.')),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: TextField(controller: manualModel, decoration: const InputDecoration(labelText: 'Model ID', hintText: 'Choose below or type an exact model ID'))),
            const SizedBox(width: 8),
            FilledButton.tonalIcon(onPressed: busy ? null : _loadModels, icon: const Icon(Icons.sync), label: const Text('Models')),
          ]),
          if (models.isNotEmpty) ...[
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: models.contains(manualModel.text) ? manualModel.text : null,
              decoration: const InputDecoration(labelText: 'Available models'),
              items: models.take(500).map((m) => DropdownMenuItem(value: m, child: Text(m, overflow: TextOverflow.ellipsis))).toList(),
              onChanged: (m) => setState(() { if (m != null) { manualModel.text = m; settings = settings.copyWith(model: m); } }),
            ),
          ],
          const SizedBox(height: 10),
          DropdownButtonFormField<AiReasoningLevel>(
            value: settings.reasoning,
            decoration: const InputDecoration(labelText: 'Thinking / reasoning level'),
            items: AiReasoningLevel.values.map((r) => DropdownMenuItem(value: r, child: Text(r.label))).toList(),
            onChanged: (r) => setState(() { if (r != null) settings = settings.copyWith(reasoning: r); }),
          ),
          const Padding(padding: EdgeInsets.only(top: 6), child: Text('The app sends the selected effort to providers/models that support it. If a model rejects X-High or Maximum, the app falls back to the nearest supported lower level and reports the effective level instead of pretending it was used.')),
          const Divider(height: 28),
          Text('AI data access', style: Theme.of(context).textTheme.titleLarge),
          SwitchListTile(value: settings.fullContext, onChanged: (v) => setState(() => settings = settings.copyWith(fullContext: v)), title: const Text('Full app context'), subtitle: const Text('Includes all locally stored wellness categories below, including highly sensitive categories. API keys/authentication secrets are never included.')),
          if (!settings.fullContext) ...[
            SwitchListTile(value: settings.includeSensitiveMentalHealth, onChanged: (v) => setState(() => settings = settings.copyWith(includeSensitiveMentalHealth: v)), title: const Text('Mental-health / trauma / self-harm data')),
            SwitchListTile(value: settings.includeSexualReproductive, onChanged: (v) => setState(() => settings = settings.copyWith(includeSexualReproductive: v)), title: const Text('Sexual / reproductive / genital tracking')),
            SwitchListTile(value: settings.includeJournals, onChanged: (v) => setState(() => settings = settings.copyWith(includeJournals: v)), title: const Text('Private journals')),
            SwitchListTile(value: settings.includeContacts, onChanged: (v) => setState(() => settings = settings.copyWith(includeContacts: v)), title: const Text('Trusted contacts')),
            SwitchListTile(value: settings.includeSafetyPlan, onChanged: (v) => setState(() => settings = settings.copyWith(includeSafetyPlan: v)), title: const Text('Safety plan')),
            SwitchListTile(value: settings.includePhotoMetadata, onChanged: (v) => setState(() => settings = settings.copyWith(includePhotoMetadata: v)), title: const Text('Progress-photo metadata'), subtitle: const Text('Encrypted image bytes are not transmitted by this text-analysis integration.')),
            SwitchListTile(value: settings.includeCommunityHistory, onChanged: (v) => setState(() => settings = settings.copyWith(includeCommunityHistory: v)), title: const Text('Locally cached community history')),
          ],
          SwitchListTile(value: settings.allowActionDrafts, onChanged: (v) => setState(() => settings = settings.copyWith(allowActionDrafts: v)), title: const Text('Allow AI to propose app actions'), subtitle: const Text('Only journal/goal drafts are supported, and nothing is saved without your approval. AI cannot change medications, contact people, delete data, or change account/admin settings.')),
          SwitchListTile(value: settings.autoInsights, onChanged: (v) => setState(() => settings = settings.copyWith(autoInsights: v)), title: const Text('Analyze new data automatically when AI Center opens'), subtitle: const Text('Off by default. This can consume provider credits and sends newly saved consented data externally.')),
          FilledButton.icon(onPressed: busy ? null : _save, icon: const Icon(Icons.save), label: const Text('Save AI configuration')),
          const Divider(height: 32),
          Text('Ask AI across the whole app', style: Theme.of(context).textTheme.titleLarge),
          Wrap(spacing: 8, runSpacing: 8, children: [
            ActionChip(label: const Text('Analyze all data'), onPressed: busy ? null : () => _run('Analyze all consented app data. Highlight the strongest patterns, important uncertainties, missing data, and the most useful next questions.')),
            ActionChip(label: const Text('Transition trends'), onPressed: busy ? null : () => _run('Analyze my transition-related measurements, HRT tracking, body-change answers, goals, and timeline. Give cautious trend estimates with plausible ranges and uncertainty.')),
            ActionChip(label: const Text('Mental-health patterns'), onPressed: busy ? null : () => _run('Analyze my consented mental-health and trauma tracking for patterns over time. Do not diagnose. Focus on triggers, coping effectiveness, safety signals, and questions I may want to discuss with a clinician.')),
            ActionChip(label: const Text('What changed?'), onPressed: busy ? null : () => _run('Compare the most recent app entries with older entries and summarize what appears to have changed, what is stable, and what is too uncertain to interpret.')),
            ActionChip(label: const Text('Personalized follow-ups'), onPressed: busy ? null : () => _run('Generate a concise set of personalized follow-up questions based only on missing, unclear, changed, or user-relevant data. Do not ask invasive questions merely out of curiosity. These are additional questions and do not replace the fixed 2,250-question library.')),
            ActionChip(label: const Text('Tune my chart'), onPressed: busy ? null : () => _run('Review my saved measurement history and, if useful, propose one chart_adjustment app action for a metric, horizon, and conservative trend strength. Explain why.')),
          ]),
          const SizedBox(height: 10),
          TextField(controller: prompt, minLines: 3, maxLines: 10, decoration: const InputDecoration(labelText: 'Ask anything about your app data')),
          const SizedBox(height: 8),
          FilledButton.icon(onPressed: busy ? null : () => _run(prompt.text.trim().isEmpty ? 'Give me the most useful analysis of my consented app data.' : prompt.text.trim()), icon: const Icon(Icons.auto_awesome), label: const Text('Run with selected AI')),
          if (busy) const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator())),
          if (status.isNotEmpty) Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: SelectableText(status)),
          if (result != null) _resultCard(result!),
          const Divider(height: 32),
          Text('Adjustable growth / measurement projection', style: Theme.of(context).textTheme.titleLarge),
          const Text('This chart extrapolates your own measurement trend. It is not a prediction of your final body or a medical prognosis. You can deliberately dampen the historic rate because real biological change rarely continues linearly.'),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: metric,
            decoration: const InputDecoration(labelText: 'Metric'),
            items: const ['weight', 'waist', 'hips', 'chest', 'bust', 'underbust', 'shoulders', 'thighs', 'glutes'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
            onChanged: (v) async { if (v != null) { setState(() => metric = v); await _buildProjection(); } },
          ),
          Text('Projection horizon: ${horizon.round()} months'),
          Slider(value: horizon, min: 3, max: 24, divisions: 21, label: '${horizon.round()} mo', onChanged: (v) => setState(() => horizon = v), onChangeEnd: (_) => _buildProjection()),
          Text('Historical trend carried forward: ${(trendStrength * 100).round()}%'),
          Slider(value: trendStrength, min: 0, max: 1, divisions: 20, label: '${(trendStrength * 100).round()}%', onChanged: (v) => setState(() => trendStrength = v), onChangeEnd: (_) => _buildProjection()),
          SizedBox(height: 240, child: projection.isEmpty ? const Center(child: Text('Save at least two measurements of this type to create a projection.')) : CustomPaint(painter: _ProjectionPainter(projection))),
          FilledButton.tonalIcon(onPressed: busy || projection.isEmpty ? null : () => _run('Interpret the adjustable $metric projection shown in the supplied chart JSON. Explain what is based on my historical measurements, what is only an extrapolation, what factors could make it wrong, and what additional measurements would improve confidence.', includeProjection: true), icon: const Icon(Icons.insights), label: const Text('Ask AI to analyze this chart')),
        ],
      ),
    );
  }

  Widget _resultCard(AiCallResult value) => Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('${value.provider.label} · ${value.model}', style: Theme.of(context).textTheme.titleMedium),
            Text('Requested: ${value.requestedReasoning.label} · Effective: ${value.effectiveReasoning}'),
            if (value.warning != null) Padding(padding: const EdgeInsets.only(top: 6), child: Text(value.warning!, style: TextStyle(color: Theme.of(context).colorScheme.tertiary))),
            const Divider(),
            SelectableText(value.text),
            if (value.actions.isNotEmpty) ...[
              const Divider(),
              const Text('AI-proposed app drafts — nothing is saved until you approve it.'),
              ...value.actions.map((a) => ListTile(
                    title: Text(a.type.replaceAll('_', ' ')),
                    subtitle: Text(prettyJson(a.payload)),
                    trailing: FilledButton.tonal(onPressed: () => _applyAction(a), child: const Text('Approve')),
                  )),
            ],
            if (value.usage != null) ExpansionTile(title: const Text('Provider usage'), children: [Padding(padding: const EdgeInsets.all(12), child: SelectableText(prettyJson(value.usage)))]),
          ]),
        ),
      );
}

class _ProjectionPainter extends CustomPainter {
  _ProjectionPainter(this.points);
  final List<AiProjectionPoint> points;

  @override
  void paint(Canvas canvas, Size size) {
    if (points.length < 2) return;
    final values = <double>[for (final p in points) ...[p.low, p.high]];
    var minV = values.reduce((a, b) => math.min(a, b).toDouble());
    var maxV = values.reduce((a, b) => math.max(a, b).toDouble());
    if ((maxV - minV).abs() < .0001) { minV -= 1; maxV += 1; }
    const pad = 18.0;
    final usableW = math.max(1.0, size.width - pad * 2).toDouble();
    final usableH = math.max(1.0, size.height - pad * 2).toDouble();
    Offset xy(int i, double v) => Offset(pad + usableW * i / (points.length - 1), pad + usableH * (1 - (v - minV) / (maxV - minV)));

    final grid = Paint()..color = Colors.grey.withValues(alpha: .25)..strokeWidth = 1;
    for (var i = 0; i <= 4; i++) {
      final y = pad + usableH * i / 4;
      canvas.drawLine(Offset(pad, y), Offset(size.width - pad, y), grid);
    }
    final band = Path()..moveTo(xy(0, points[0].high).dx, xy(0, points[0].high).dy);
    for (var i = 1; i < points.length; i++) band.lineTo(xy(i, points[i].high).dx, xy(i, points[i].high).dy);
    for (var i = points.length - 1; i >= 0; i--) band.lineTo(xy(i, points[i].low).dx, xy(i, points[i].low).dy);
    band.close();
    canvas.drawPath(band, Paint()..color = Colors.grey.withValues(alpha: .18));
    final line = Path()..moveTo(xy(0, points[0].value).dx, xy(0, points[0].value).dy);
    for (var i = 1; i < points.length; i++) line.lineTo(xy(i, points[i].value).dx, xy(i, points[i].value).dy);
    canvas.drawPath(line, Paint()..color = Colors.grey.shade700..strokeWidth = 3..style = PaintingStyle.stroke);
  }

  @override
  bool shouldRepaint(covariant _ProjectionPainter oldDelegate) => oldDelegate.points != points;
}

import 'package:flutter/material.dart';
import '../models/question.dart';
import '../services/api_client.dart';
import '../services/secure_vault.dart';
import 'accessibility_screen.dart';
import 'admin_screen.dart';
import 'ai_estimates_screen.dart';
import 'ai_center_screen.dart';
import 'checkin_screen.dart';
import 'community_screen.dart';
import 'companion_screen.dart';
import 'contacts_screen.dart';
import 'crisis_mode_screen.dart';
import 'dashboard_screens.dart';
import 'journals_screen.dart';
import 'knowledge_screen.dart';
import 'measurements_screen.dart';
import 'photo_tracking_screen.dart';
import 'preferences_screen.dart';
import 'privacy_center_screen.dart';
import 'question_library_screen.dart';
import 'safety_plan_screen.dart';
import 'tools_screen.dart';

class HomeScreen extends StatelessWidget{
 const HomeScreen({super.key,required this.questions,required this.vault,required this.preview,required this.api,required this.onUiChanged});
 final Map<String,List<WellnessQuestion>> questions;final SecureVault vault;final bool preview;final ApiClient api;final ValueChanged<Map<String,dynamic>> onUiChanged;
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Private Wellness')),body:ListView(padding:const EdgeInsets.all(16),children:[
  if(preview)const Card(child:ListTile(leading:Icon(Icons.visibility_outlined),title:Text('Offline private preview'),subtitle:Text('Local wellness tools work without an account. Community enrollment still requires a valid invitation.'))),
  Text('Your private control center',style:Theme.of(c).textTheme.headlineMedium),const SizedBox(height:8),const Text('Transition tracking, trauma-informed wellness tools, private data, and invite-only community features in one app.'),const SizedBox(height:14),
  _tile(c,Icons.tune,'Personalize my app','Choose which transition, mental-health and social topics you want to see',()=>_go(c,PreferencesScreen(vault:vault))),
  _tile(c,Icons.quiz_outlined,'Complete question library','Exactly 2,250 structured questions: TM 750 · TW 750 · MH 750',()=>_go(c,QuestionLibraryScreen(questions:questions,vault:vault))),
  _tile(c,Icons.straighten,'Measurements','Encrypted height, weight and body-proportion history',()=>_go(c,MeasurementsScreen(vault:vault))),
  _tile(c,Icons.show_chart,'Transition dashboard','Current metrics, questionnaire progress and longitudinal tracking',()=>_go(c,TransitionDashboardScreen(vault:vault))),
  _tile(c,Icons.psychology_alt_outlined,'Mental-health dashboard','Mood, anxiety, dissociation, safety and coping trends',()=>_go(c,MentalHealthDashboardScreen(vault:vault))),
  _tile(c,Icons.fact_check_outlined,'Wellness check-in','Optional trauma-informed symptom and safety tracking',()=>_go(c,CheckInScreen(vault:vault))),
  _tile(c,Icons.hub_outlined,'Integrated AI Center','OpenAI, OpenRouter, Groq, Poe or another OpenAI-compatible provider with model selection, real reasoning controls and consented full-app context',()=>_go(c,AiCenterScreen(vault:vault,questions:questions))),
  _tile(c,Icons.auto_awesome_outlined,'Local estimates','Bra-size range and personal measurement trends with uncertainty; no external AI required',()=>_go(c,AiEstimatesScreen(vault:vault))),
  _tile(c,Icons.photo_camera_back_outlined,'Private photo tracking','Encrypted optional progress photos with AI analysis off by default',()=>_go(c,PhotoTrackingScreen(vault:vault,questions:questions))),
  _tile(c,Icons.menu_book_outlined,'Private journals','15 journal types with encrypted local storage and tags',()=>_go(c,JournalsScreen(vault:vault))),
  _tile(c,Icons.contacts_outlined,'Trusted contacts','Support people, professionals and consent-to-contact settings',()=>_go(c,ContactsScreen(vault:vault))),
  _tile(c,Icons.health_and_safety_outlined,'Safety plan','Twenty-part customizable personal safety plan',()=>_go(c,SafetyPlanScreen(vault:vault))),
  _tile(c,Icons.emergency_outlined,'Crisis Mode','Low-stimulation access to your saved plan, grounding and contacts',()=>_go(c,CrisisModeScreen(vault:vault))),
  _tile(c,Icons.chat_bubble_outline,'Wellness companion','Uses your selected external AI and consented app context when configured, with a local safety fallback',()=>_go(c,CompanionScreen(vault:vault,questions:questions))),
  _tile(c,Icons.school_outlined,'Knowledge library','Trauma, dissociation, treatment approaches, grounding, boundaries and recovery',()=>_go(c,const KnowledgeScreen())),
  _tile(c,Icons.people_alt_outlined,'Private community','Invite-only posts, visibility settings, profiles and moderation backend',()=>_go(c,CommunityScreen(api:api,preview:preview,vault:vault))),
  if(!preview)_tile(c,Icons.admin_panel_settings_outlined,'Leadership & administration','XXX / XX invite administration and auditable authority',()=>_go(c,AdminScreen(api:api))),
  _tile(c,Icons.checklist,'Goals, habits & reminders','Medication/HRT/appointment/refill/lab/measurement plans, habits and tasks',()=>_go(c,ToolsScreen(vault:vault))),
  _tile(c,Icons.accessibility_new,'Accessibility & sensory settings','Theme, text size, reduced motion, contrast and low-stimulation preferences',()=>_go(c,AccessibilityScreen(vault:vault,onChanged:onUiChanged))),
  _tile(c,Icons.lock_outline,'Privacy center','Encrypted local vault, data inventory, export and deletion',()=>_go(c,PrivacyCenterScreen(vault:vault))),
 ]));
 Widget _tile(BuildContext c,IconData i,String t,String s,VoidCallback onTap)=>Card(child:ListTile(leading:Icon(i),title:Text(t),subtitle:Text(s),trailing:const Icon(Icons.chevron_right),onTap:onTap));
 void _go(BuildContext c,Widget page)=>Navigator.push(c,MaterialPageRoute(builder:(_)=>page));
}

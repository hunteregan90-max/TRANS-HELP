import 'package:flutter/material.dart';
import '../services/secure_vault.dart';

class MeasurementsScreen extends StatefulWidget {
  const MeasurementsScreen({super.key, required this.vault});
  final SecureVault vault;
  @override State<MeasurementsScreen> createState() => _MeasurementsScreenState();
}

class _MeasurementsScreenState extends State<MeasurementsScreen> {
  static const types = ['height','weight','neck','shoulders','chest','underbust','bust','waist','high hip','hips','thighs','calves','biceps','forearms','wrists','glutes'];
  String type='weight', unit='lb';
  final value=TextEditingController();
  List<Map<String,dynamic>> entries=[];
  @override void initState(){super.initState(); _load();}
  @override void dispose(){value.dispose();super.dispose();}
  Future<void> _load() async { final raw=await widget.vault.readValue('measurements',fallback:const []); if(!mounted)return; setState(()=>entries=List<Map<String,dynamic>>.from((raw as List).map((e)=>Map<String,dynamic>.from(e as Map)))); }
  Future<void> _save() async { final n=double.tryParse(value.text.trim()); if(n==null)return; await widget.vault.appendToCollection('measurements',{'id':DateTime.now().microsecondsSinceEpoch.toString(),'type':type,'value':n,'unit':unit,'date':DateTime.now().toUtc().toIso8601String()}); value.clear(); await _load(); }
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Measurements')),body:ListView(padding:const EdgeInsets.all(16),children:[
    Text('Private body measurements',style:Theme.of(c).textTheme.headlineSmall), const Text('Stored in the encrypted local vault unless you explicitly export them.'), const SizedBox(height:16),
    Row(children:[Expanded(child:DropdownButtonFormField<String>(value:type,decoration:const InputDecoration(labelText:'Measurement'),items:types.map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>type=v!))),const SizedBox(width:12),SizedBox(width:110,child:DropdownButtonFormField<String>(value:unit,decoration:const InputDecoration(labelText:'Unit'),items:['in','cm','lb','kg'].map((e)=>DropdownMenuItem(value:e,child:Text(e))).toList(),onChanged:(v)=>setState(()=>unit=v!)))]), const SizedBox(height:12),
    TextField(controller:value,keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:const InputDecoration(labelText:'Value')),const SizedBox(height:12),FilledButton.icon(onPressed:_save,icon:const Icon(Icons.add),label:const Text('Save measurement')),const Divider(height:32),
    Text('Recent entries',style:Theme.of(c).textTheme.titleLarge),
    if(entries.isEmpty) const ListTile(title:Text('No measurements yet')),
    ...entries.take(60).map((e)=>ListTile(leading:const Icon(Icons.straighten),title:Text('${e['type']}: ${e['value']} ${e['unit']}'),subtitle:Text('${e['date']}'))),
  ]));
}

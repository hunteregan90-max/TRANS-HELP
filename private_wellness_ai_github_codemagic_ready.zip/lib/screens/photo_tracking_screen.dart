import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import '../models/ai_models.dart';
import '../models/question.dart';
import '../services/ai_context_builder.dart';
import '../services/ai_provider_service.dart';
import '../services/secure_vault.dart';

class PhotoTrackingScreen extends StatefulWidget {
  const PhotoTrackingScreen({super.key, required this.vault, required this.questions});
  final SecureVault vault;
  final Map<String, List<WellnessQuestion>> questions;
  @override
  State<PhotoTrackingScreen> createState() => _PhotoTrackingScreenState();
}

class _PhotoTrackingScreenState extends State<PhotoTrackingScreen> {
  static const categories = ['face', 'profile', 'torso', 'chest', 'waist', 'hips', 'legs', 'hair', 'beard', 'skin', 'posture', 'clothing fit'];
  final picker = ImagePicker();
  final providerService = AiProviderService();
  final credentials = const AiCredentialStore();
  String category = 'face';
  String busyId = '';
  List<Map<String, dynamic>> items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final raw = await widget.vault.readValue('photos', fallback: const []);
    if (mounted) setState(() => items = List<Map<String, dynamic>>.from((raw as List).map((e) => Map<String, dynamic>.from(e as Map))));
  }

  Future<void> _pick(ImageSource source) async {
    final x = await picker.pickImage(source: source, imageQuality: 88, maxWidth: 2200);
    if (x == null) return;
    final bytes = await x.readAsBytes();
    final id = DateTime.now().microsecondsSinceEpoch.toString();
    final path = await widget.vault.writeEncryptedBlob(id, bytes);
    await widget.vault.appendToCollection('photos', {
      'id': id,
      'category': category,
      'path': path,
      'mime_type': x.mimeType ?? _guessMime(bytes),
      'created_at': DateTime.now().toUtc().toIso8601String(),
      'ai_analysis_opt_in': false,
      'shared': false,
    });
    await _load();
  }

  String _guessMime(Uint8List bytes) {
    if (bytes.length >= 4 && bytes[0] == 0x89 && bytes[1] == 0x50 && bytes[2] == 0x4e && bytes[3] == 0x47) return 'image/png';
    if (bytes.length >= 3 && bytes[0] == 0xff && bytes[1] == 0xd8 && bytes[2] == 0xff) return 'image/jpeg';
    if (bytes.length >= 12 && String.fromCharCodes(bytes.sublist(8, 12)) == 'WEBP') return 'image/webp';
    return 'image/jpeg';
  }

  Future<void> _analyze(Map<String, dynamic> item) async {
    final raw = await widget.vault.readValue('ai_settings', fallback: const <String, dynamic>{});
    final settings = AiSettings.fromJson(Map<String, dynamic>.from(raw as Map));
    if (!settings.ready) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Configure and consent to external AI in Integrated AI Center first.')));
      return;
    }
    final ok = await showDialog<bool>(
          context: context,
          builder: (c) => AlertDialog(
            title: const Text('Send this private photo to external AI?'),
            content: Text('This will decrypt this one photo on-device and send it, plus your currently consented app context, to ${settings.provider.label} using ${settings.model}. The provider may retain or log it under its own policies. Continue?'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
              FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Send to AI')),
            ],
          ),
        ) ??
        false;
    if (!ok) return;
    setState(() => busyId = '${item['id']}');
    try {
      final bytes = await widget.vault.readEncryptedBlob('${item['path']}');
      if (bytes == null) throw Exception('Encrypted image could not be opened.');
      final mime = '${item['mime_type'] ?? _guessMime(bytes)}';
      final dataUrl = 'data:$mime;base64,${base64Encode(bytes)}';
      final key = await credentials.read(settings.provider);
      final appContext = await AiContextBuilder(widget.questions).build(widget.vault, settings);
      final response = await providerService.generate(
        settings: settings,
        apiKey: key,
        imageDataUrls: [dataUrl],
        maxOutputTokens: 2200,
        instructions: '''You are the optional vision-analysis layer inside a private transition-wellness tracking app. Analyze only what is visibly relevant to the user's requested progress category. Do not infer gender identity, sexual orientation, ethnicity, diagnosis, mental-health condition, exact age, fertility, surgical eligibility, or other sensitive traits from appearance. Do not claim precise body measurements from a photograph. Distinguish visible observation from uncertain interpretation and do not promise future transition outcomes.''',
        userPrompt: '''Analyze this progress photo for the user-selected category "${item['category']}". Compare only against patterns explicitly present in the consented app context when useful. Give cautious observations, possible changes to track over time, photo/measurement consistency tips, and uncertainty.\n\nCONSENTED APP CONTEXT:\n$appContext''',
      );
      final updated = items.map((row) {
        if ('${row['id']}' != '${item['id']}') return row;
        final copy = Map<String, dynamic>.from(row);
        copy['ai_analysis_opt_in'] = true;
        copy['ai_analysis'] = response.text;
        copy['ai_provider'] = response.provider.label;
        copy['ai_model'] = response.model;
        copy['ai_reasoning'] = response.effectiveReasoning;
        copy['ai_analyzed_at'] = DateTime.now().toUtc().toIso8601String();
        return copy;
      }).toList();
      await widget.vault.replaceCollection('photos', updated);
      await _load();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$e')));
    } finally {
      if (mounted) setState(() => busyId = '');
    }
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        appBar: AppBar(title: const Text('Private Photo Tracking')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Card(
              child: ListTile(
                leading: Icon(Icons.lock),
                title: Text('Encrypted and private by default'),
                subtitle: Text('Selected images are copied into encrypted app storage. External AI photo analysis requires both global AI consent and a separate confirmation for each photo. Nothing is shared automatically.'),
              ),
            ),
            DropdownButtonFormField<String>(value: category, items: categories.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => category = v!)),
            const SizedBox(height: 10),
            Wrap(spacing: 10, children: [
              FilledButton.icon(onPressed: () => _pick(ImageSource.gallery), icon: const Icon(Icons.photo_library_outlined), label: const Text('Choose photo')),
              OutlinedButton.icon(onPressed: () => _pick(ImageSource.camera), icon: const Icon(Icons.camera_alt_outlined), label: const Text('Take photo')),
            ]),
            const Divider(height: 30),
            if (items.isEmpty) const ListTile(title: Text('No private progress photos yet')),
            ...items.take(30).map(
                  (e) => Card(
                    child: Padding(
                      padding: const EdgeInsets.all(10),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          SizedBox(
                            width: 82,
                            height: 82,
                            child: FutureBuilder<Uint8List?>(
                              future: widget.vault.readEncryptedBlob('${e['path']}'),
                              builder: (c, s) => s.hasData && s.data != null ? Image.memory(s.data!, fit: BoxFit.cover) : const Center(child: CircularProgressIndicator()),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${e['category']}', style: Theme.of(c).textTheme.titleMedium), Text('${e['created_at']}'), Text(e['ai_analysis_opt_in'] == true ? 'AI analysis: completed' : 'AI analysis: off')])),
                          FilledButton.tonalIcon(onPressed: busyId.isNotEmpty ? null : () => _analyze(e), icon: const Icon(Icons.auto_awesome), label: const Text('AI')),
                        ]),
                        if (busyId == '${e['id']}') const LinearProgressIndicator(),
                        if ('${e['ai_analysis'] ?? ''}'.isNotEmpty) ExpansionTile(title: Text('${e['ai_provider'] ?? 'AI'} · ${e['ai_model'] ?? ''}'), subtitle: Text('Reasoning: ${e['ai_reasoning'] ?? ''}'), children: [Padding(padding: const EdgeInsets.all(12), child: SelectableText('${e['ai_analysis']}'))]),
                      ]),
                    ),
                  ),
                ),
          ],
        ),
      );
}

import 'package:flutter/material.dart';
import '../services/secure_vault.dart';

class TransitionDashboardScreen extends StatefulWidget {
  const TransitionDashboardScreen({super.key, required this.vault});
  final SecureVault vault;
  @override
  State<TransitionDashboardScreen> createState() => _TransitionDashboardScreenState();
}

class _TransitionDashboardScreenState extends State<TransitionDashboardScreen> {
  int measurements = 0;
  int answers = 0;
  int journals = 0;
  Map<String, dynamic> latest = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final raw = await widget.vault.readValue('measurements', fallback: const []);
    final m = List<Map<String, dynamic>>.from(
      (raw as List).map((e) => Map<String, dynamic>.from(e as Map)),
    );
    final map = <String, dynamic>{};
    for (final e in m) {
      map.putIfAbsent('${e['type']}', () => e);
    }
    final a = await widget.vault.readAnswers();
    final j = await widget.vault.itemCount('journals');
    if (mounted) {
      setState(() {
        measurements = m.length;
        answers = a.length;
        journals = j;
        latest = map;
      });
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Transition Dashboard')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                _stat(context, 'Measurements', '$measurements'),
                _stat(context, 'Question answers', '$answers'),
                _stat(context, 'Journal entries', '$journals'),
              ],
            ),
            const SizedBox(height: 18),
            Text('Latest body metrics', style: Theme.of(context).textTheme.titleLarge),
            if (latest.isEmpty) const ListTile(title: Text('No measurement data yet')),
            ...latest.entries.map((e) {
              final v = e.value as Map<String, dynamic>;
              return ListTile(
                leading: const Icon(Icons.show_chart),
                title: Text(e.key),
                trailing: Text('${v['value']} ${v['unit']}'),
              );
            }),
            const Card(
              child: ListTile(
                leading: Icon(Icons.auto_awesome),
                title: Text('AI estimates remain separate from medical decisions'),
                subtitle: Text('Medication changes are never made automatically from trend estimates.'),
              ),
            ),
          ],
        ),
      );

  Widget _stat(BuildContext context, String label, String value) => SizedBox(
        width: 160,
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(value, style: Theme.of(context).textTheme.headlineSmall),
                Text(label),
              ],
            ),
          ),
        ),
      );
}

class MentalHealthDashboardScreen extends StatefulWidget {
  const MentalHealthDashboardScreen({super.key, required this.vault});
  final SecureVault vault;
  @override
  State<MentalHealthDashboardScreen> createState() => _MentalHealthDashboardScreenState();
}

class _MentalHealthDashboardScreenState extends State<MentalHealthDashboardScreen> {
  List<Map<String, dynamic>> items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final raw = await widget.vault.readValue('mental_checkins', fallback: const []);
    if (mounted) {
      setState(() => items = List<Map<String, dynamic>>.from(
            (raw as List).map((e) => Map<String, dynamic>.from(e as Map)),
          ));
    }
  }

  double avg(String key) {
    if (items.isEmpty) return 0;
    final vals = items
        .map((e) => (e[key] as num?)?.toDouble())
        .whereType<double>()
        .toList();
    return vals.isEmpty ? 0 : vals.reduce((a, b) => a + b) / vals.length;
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Mental-health Dashboard')),
        body: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            const Text('Trend summaries reflect your own check-ins and are not diagnoses.'),
            const SizedBox(height: 12),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                for (final key in [
                  'mood',
                  'anxiety',
                  'dissociation',
                  'self_harm_urge',
                  'felt_safety',
                  'coping_effectiveness',
                ])
                  SizedBox(
                    width: 165,
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(14),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(avg(key).toStringAsFixed(1), style: Theme.of(context).textTheme.headlineSmall),
                            Text(key.replaceAll('_', ' ')),
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
            const Divider(height: 32),
            Text('Recent check-ins', style: Theme.of(context).textTheme.titleLarge),
            ...items.take(20).map(
                  (e) => ListTile(
                    title: Text('${e['created_at']}'),
                    subtitle: Text('Mood ${e['mood']}/10 · Anxiety ${e['anxiety']}/10 · Safety ${e['felt_safety']}/10'),
                  ),
                ),
          ],
        ),
      );
}

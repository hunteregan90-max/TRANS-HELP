import 'package:flutter/material.dart';

class KnowledgeScreen extends StatelessWidget {
  const KnowledgeScreen({super.key});
  static const topics=<String,String>{
    'Trauma':'Trauma responses can affect emotion, attention, sleep, memory, relationships and the body. Reactions vary widely; a questionnaire cannot determine a diagnosis.',
    'PTSD and complex trauma':'PTSD-like symptoms can include intrusions, avoidance, threat sensitivity and changes in mood or cognition. Complex trauma discussions may also include emotion regulation, self-concept and relationship patterns.',
    'Dissociation':'Dissociation can involve disconnection from thoughts, feelings, memory, identity, body or surroundings. Similar experiences can occur for many reasons, so careful professional assessment can matter.',
    'DID / parts-informed care':'Some people already use parts or system language for their experiences. This app can organize user-chosen language without diagnosing DID, creating identities, or encouraging symptom escalation.',
    'Depersonalization / derealization':'These experiences can involve feeling detached from oneself or as if surroundings are unreal or dreamlike. Grounding may help some people, but not every technique fits everyone.',
    'Depression':'Low mood, reduced interest, energy changes, sleep/appetite changes and hopelessness can affect functioning. Screening answers are not the same as a clinical diagnosis.',
    'Anxiety and panic':'Anxiety can involve worry, physical arousal and avoidance. Panic can feel intense and frightening even when the episode itself is time-limited.',
    'Self-harm safety':'The safety approach focuses on urges, immediate safety, support, medical needs, coping and reducing access to dangerous means. It avoids graphic method detail or concealment guidance.',
    'Grounding':'Grounding techniques orient attention toward the present through senses, movement, breathing, objects, facts about the environment or connection with another person.',
    'CBT':'Cognitive behavioral therapy examines links among thoughts, emotions and behavior and uses structured skills and experiments. It is not universally right for every person or every stage of trauma work.',
    'DBT':'Dialectical behavior therapy teaches mindfulness, distress tolerance, emotion regulation and interpersonal effectiveness and is often adapted to the person and treatment setting.',
    'ACT':'Acceptance and commitment therapy emphasizes psychological flexibility, values and changing how one relates to difficult internal experiences rather than simply trying to eliminate them.',
    'EMDR':'Eye movement desensitization and reprocessing is a structured trauma therapy delivered by trained clinicians. Readiness, stabilization and individual context matter.',
    'Exposure-based approaches':'Exposure-based therapies can be effective for some trauma and anxiety presentations when clinically appropriate, planned and paced with qualified support.',
    'Somatic-oriented approaches':'Body-oriented approaches may attend to sensations, movement, arousal and regulation. Evidence and methods vary by approach, so they should not be treated as one uniform treatment.',
    'Medication basics':'Psychiatric and hormone medications can have benefits, side effects, interactions and monitoring needs. The app tracks information but does not tell users to stop or change prescribed medication.',
    'Boundaries and relationship safety':'Healthy boundaries concern consent, access, communication, privacy and what a person is willing to do. Abuse or coercion can make boundary-setting more complex and may require external support.',
    'Recovery and resilience':'Recovery is often nonlinear. Progress can involve safety, support, functioning, self-understanding, skills, meaning, connection and living in ways aligned with personal values.'
  };
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Mental-health Knowledge Library')),body:ListView(padding:const EdgeInsets.all(16),children:[const Card(child:ListTile(leading:Icon(Icons.school_outlined),title:Text('Psychoeducation, not diagnosis'),subtitle:Text('No single therapy is presented as universally correct. Educational content should support—not replace—qualified care.'))),...topics.entries.map((e)=>ExpansionTile(title:Text(e.key),children:[Padding(padding:const EdgeInsets.fromLTRB(16,0,16,16),child:Text(e.value))]))]));
}

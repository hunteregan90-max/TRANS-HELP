import 'package:flutter/material.dart';
import '../services/api_client.dart';

class EnrollmentScreen extends StatefulWidget {
  const EnrollmentScreen({super.key, required this.api, required this.onAuthenticated, required this.onPreview});
  final ApiClient api;
  final VoidCallback onAuthenticated;
  final VoidCallback onPreview;
  @override State<EnrollmentScreen> createState()=>_EnrollmentScreenState();
}
class _EnrollmentScreenState extends State<EnrollmentScreen>{
  final invite=TextEditingController(), user=TextEditingController(), pass=TextEditingController(), name=TextEditingController();
  bool loginMode=false, busy=false; String? error;
  @override void dispose(){ for(final c in [invite,user,pass,name]){c.dispose();} super.dispose(); }
  Future<void> submit() async { setState(() { busy=true; error=null; }); try { if(loginMode){await widget.api.login(user.text.trim(),pass.text);} else {await widget.api.register(invite:invite.text.trim(),username:user.text.trim(),password:pass.text,displayName:name.text.trim());} widget.onAuthenticated(); } catch(e){setState(()=>error=e.toString());} finally {if(mounted)setState(()=>busy=false);} }
  @override Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:Center(child:SingleChildScrollView(padding:const EdgeInsets.all(24),child:ConstrainedBox(constraints:const BoxConstraints(maxWidth:560),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    Text('Private Wellness',style:Theme.of(c).textTheme.displaySmall), const SizedBox(height:8),
    const Text('Invite-only transition wellness, trauma-informed tracking, private journals, and support tools.'), const SizedBox(height:24),
    if(!loginMode) ...[TextField(controller:invite,decoration:const InputDecoration(labelText:'35-character invitation code')),const SizedBox(height:12),TextField(controller:name,decoration:const InputDecoration(labelText:'Display name')),const SizedBox(height:12)],
    TextField(controller:user,decoration:const InputDecoration(labelText:'Username')),const SizedBox(height:12),
    TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'Password')),const SizedBox(height:12),
    if(error!=null) Text(error!,style:TextStyle(color:Theme.of(c).colorScheme.error)),
    FilledButton(onPressed:busy?null:submit,child:Text(loginMode?'Sign in':'Create invite-only account')),
    TextButton(onPressed:()=>setState(()=>loginMode=!loginMode),child:Text(loginMode?'Have an invite? Create account':'Already enrolled? Sign in')),
    const Divider(height:32),
    OutlinedButton(onPressed:widget.onPreview,child:const Text('Open offline private preview (no account created)')),
    const SizedBox(height:8), const Text('Preview mode never joins the community and does not bypass invite-only account registration.',textAlign:TextAlign.center),
  ]))))));
}

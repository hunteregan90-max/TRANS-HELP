import 'dart:convert';
import 'package:flutter/services.dart';
import '../models/question.dart';

class QuestionRepository {
  Future<Map<String, List<WellnessQuestion>>> load() async {
    final raw = await rootBundle.loadString('assets/questions/questions.json');
    final data = jsonDecode(raw) as Map<String, dynamic>;
    return data.map((key, value) => MapEntry(
      key,
      (value as List<dynamic>)
          .map((e) => WellnessQuestion.fromJson(Map<String, dynamic>.from(e as Map)))
          .toList(growable: false),
    ));
  }
}

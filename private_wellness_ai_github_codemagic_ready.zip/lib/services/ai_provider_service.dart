import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;
import '../models/ai_models.dart';

class AiCredentialStore {
  const AiCredentialStore();
  static const _secure = FlutterSecureStorage();

  String _key(AiProviderKind provider) => 'ai_api_key_${provider.name}';

  Future<String> read(AiProviderKind provider) async => await _secure.read(key: _key(provider)) ?? '';

  Future<void> write(AiProviderKind provider, String value) async {
    final trimmed = value.trim();
    if (trimmed.isEmpty) {
      await _secure.delete(key: _key(provider));
    } else {
      await _secure.write(key: _key(provider), value: trimmed);
    }
  }

  Future<void> delete(AiProviderKind provider) => _secure.delete(key: _key(provider));

  Future<void> clearAll() async {
    for (final provider in AiProviderKind.values) {
      await delete(provider);
    }
  }
}

class AiProviderService {
  AiProviderService({http.Client? client}) : _client = client ?? http.Client();
  final http.Client _client;

  Map<String, String> _headers(String apiKey, AiProviderKind provider) => {
        if (apiKey.trim().isNotEmpty) 'authorization': 'Bearer ${apiKey.trim()}',
        'content-type': 'application/json',
        'accept': 'application/json',
        if (provider == AiProviderKind.openrouter) 'x-title': 'Private Wellness',
      };

  Future<List<String>> listModels(AiSettings settings, String apiKey) async {
    if (settings.baseUrl.isEmpty) throw Exception('A base URL is required.');
    final response = await _client.get(
      Uri.parse('${settings.baseUrl}/models'),
      headers: _headers(apiKey, settings.provider),
    );
    if (response.statusCode >= 400) {
      throw Exception(_errorText(response));
    }
    final decoded = jsonDecode(response.body);
    final rows = decoded is Map ? decoded['data'] : null;
    if (rows is! List) return const [];
    final ids = <String>[];
    for (final row in rows) {
      if (row is Map && row['id'] != null) ids.add('${row['id']}');
    }
    ids.sort((a, b) => a.toLowerCase().compareTo(b.toLowerCase()));
    return ids.toSet().toList();
  }

  Future<AiCallResult> generate({
    required AiSettings settings,
    required String apiKey,
    required String userPrompt,
    required String instructions,
    int maxOutputTokens = 6000,
    List<String> imageDataUrls = const [],
  }) async {
    if (!settings.ready) throw Exception('AI is not fully configured or consent has not been accepted.');
    if (apiKey.trim().isEmpty) throw Exception('No API key is saved for ${settings.provider.label}.');

    final attempts = _reasoningFallbacks(settings.reasoning);
    http.Response? last;
    String? lastReasoning;
    for (final effort in attempts) {
      lastReasoning = effort ?? 'provider default';
      final body = <String, dynamic>{
        'model': settings.model,
        'instructions': instructions,
        'input': imageDataUrls.isEmpty
            ? userPrompt
            : [
                {
                  'role': 'user',
                  'content': [
                    {'type': 'input_text', 'text': userPrompt},
                    for (final image in imageDataUrls) {'type': 'input_image', 'image_url': image, 'detail': 'auto'},
                  ],
                }
              ],
        'max_output_tokens': maxOutputTokens,
        if (effort != null) 'reasoning': {'effort': effort},
      };
      final response = await _client.post(
        Uri.parse('${settings.baseUrl}/responses'),
        headers: _headers(apiKey, settings.provider),
        body: jsonEncode(body),
      );
      last = response;
      if (response.statusCode < 400) {
        final decoded = jsonDecode(response.body);
        final map = decoded is Map ? Map<String, dynamic>.from(decoded) : <String, dynamic>{};
        final parsed = _extractTextAndActions(map);
        final usedModel = '${map['model'] ?? settings.model}';
        final usageRaw = map['usage'];
        return AiCallResult(
          text: parsed.$1,
          provider: settings.provider,
          model: usedModel,
          requestedReasoning: settings.reasoning,
          effectiveReasoning: lastReasoning,
          actions: parsed.$2,
          usage: usageRaw is Map ? Map<String, dynamic>.from(usageRaw) : null,
          warning: effort == settings.reasoning.apiValue
              ? null
              : 'The selected model rejected ${settings.reasoning.label}; the request succeeded using $lastReasoning.',
        );
      }
      if (!_looksLikeUnsupportedReasoning(response)) break;
    }

    if (last != null && (last.statusCode == 404 || last.statusCode == 405)) {
      return _generateChatFallback(
        settings: settings,
        apiKey: apiKey,
        userPrompt: userPrompt,
        instructions: instructions,
        maxOutputTokens: maxOutputTokens,
        imageDataUrls: imageDataUrls,
      );
    }
    throw Exception(last == null ? 'AI request failed.' : _errorText(last));
  }

  Future<AiCallResult> _generateChatFallback({
    required AiSettings settings,
    required String apiKey,
    required String userPrompt,
    required String instructions,
    required int maxOutputTokens,
    List<String> imageDataUrls = const [],
  }) async {
    final body = <String, dynamic>{
      'model': settings.model,
      'messages': [
        {'role': 'system', 'content': instructions},
        {
          'role': 'user',
          'content': imageDataUrls.isEmpty
              ? userPrompt
              : [
                  {'type': 'text', 'text': userPrompt},
                  for (final image in imageDataUrls) {'type': 'image_url', 'image_url': {'url': image}},
                ],
        },
      ],
      'max_tokens': maxOutputTokens,
      if (settings.provider == AiProviderKind.groq) 'reasoning_effort': settings.reasoning.apiValue,
      if (settings.provider == AiProviderKind.openrouter) 'reasoning': {'effort': settings.reasoning.apiValue},
    };
    final response = await _client.post(
      Uri.parse('${settings.baseUrl}/chat/completions'),
      headers: _headers(apiKey, settings.provider),
      body: jsonEncode(body),
    );
    if (response.statusCode >= 400) throw Exception(_errorText(response));
    final decoded = jsonDecode(response.body) as Map<String, dynamic>;
    final choices = decoded['choices'];
    String text = '';
    if (choices is List && choices.isNotEmpty && choices.first is Map) {
      final message = (choices.first as Map)['message'];
      if (message is Map) text = '${message['content'] ?? ''}';
    }
    final parsed = _extractInlineActions(text);
    return AiCallResult(
      text: parsed.$1,
      provider: settings.provider,
      model: '${decoded['model'] ?? settings.model}',
      requestedReasoning: settings.reasoning,
      effectiveReasoning: settings.provider == AiProviderKind.poe ? 'provider/model default' : settings.reasoning.apiValue,
      actions: parsed.$2,
      usage: decoded['usage'] is Map ? Map<String, dynamic>.from(decoded['usage'] as Map) : null,
      warning: 'This provider used the Chat Completions compatibility fallback; reasoning controls may be model-dependent.',
    );
  }

  (String, List<AiAppAction>) _extractTextAndActions(Map<String, dynamic> response) {
    final parts = <String>[];
    final output = response['output'];
    if (output is List) {
      for (final item in output) {
        if (item is! Map) continue;
        final content = item['content'];
        if (content is List) {
          for (final block in content) {
            if (block is Map && (block['type'] == 'output_text' || block['type'] == 'text')) {
              final text = block['text'];
              if (text != null) parts.add('$text');
            }
          }
        }
      }
    }
    if (parts.isEmpty && response['output_text'] != null) parts.add('${response['output_text']}');
    return _extractInlineActions(parts.join('\n').trim());
  }

  (String, List<AiAppAction>) _extractInlineActions(String text) {
    final actions = <AiAppAction>[];
    final pattern = RegExp(r'<app_actions>([\s\S]*?)</app_actions>', caseSensitive: false);
    final match = pattern.firstMatch(text);
    if (match != null) {
      try {
        final decoded = jsonDecode(match.group(1)!.trim());
        if (decoded is List) {
          for (final row in decoded) {
            if (row is Map) actions.add(AiAppAction.fromJson(Map<String, dynamic>.from(row)));
          }
        }
      } catch (_) {
        // A malformed optional action block should never discard the useful answer.
      }
    }
    return (text.replaceAll(pattern, '').trim(), actions);
  }

  List<String?> _reasoningFallbacks(AiReasoningLevel level) => switch (level) {
        AiReasoningLevel.minimum => const ['low', null],
        AiReasoningLevel.medium => const ['medium', 'low', null],
        AiReasoningLevel.high => const ['high', 'medium', 'low', null],
        AiReasoningLevel.xHigh => const ['xhigh', 'high', 'medium', 'low', null],
        AiReasoningLevel.maximum => const ['max', 'xhigh', 'high', 'medium', 'low', null],
      };

  bool _looksLikeUnsupportedReasoning(http.Response response) {
    if (response.statusCode != 400 && response.statusCode != 422) return false;
    final text = response.body.toLowerCase();
    return text.contains('reasoning') || text.contains('effort') || text.contains('unsupported') || text.contains('invalid value');
  }

  String _errorText(http.Response response) {
    try {
      final decoded = jsonDecode(response.body);
      if (decoded is Map) {
        final error = decoded['error'];
        if (error is Map && error['message'] != null) return '${error['message']}';
        if (decoded['detail'] != null) return '${decoded['detail']}';
        if (decoded['message'] != null) return '${decoded['message']}';
      }
    } catch (_) {}
    final body = response.body.trim();
    return body.isEmpty ? 'Request failed (${response.statusCode}).' : 'Request failed (${response.statusCode}): $body';
  }
}

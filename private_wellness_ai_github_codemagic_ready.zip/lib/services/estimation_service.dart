import 'dart:math' as math;

class BraEstimate {
  const BraEstimate({required this.primary, required this.alternatives, required this.confidence, required this.dataQuality, required this.explanation});
  final String primary;
  final List<String> alternatives;
  final int confidence;
  final String dataQuality;
  final String explanation;
}

class TrendEstimate {
  const TrendEstimate({required this.metric, required this.current, required this.direction, required this.monthlyRate, required this.confidence, required this.dataQuality, required this.limitations});
  final String metric;
  final double current;
  final String direction;
  final double monthlyRate;
  final int confidence;
  final String dataQuality;
  final String limitations;
}

class EstimationService {
  BraEstimate estimateBra({
    required double snugUnderbust,
    required double standingBust,
    double? leaningBust,
    double? lyingBust,
    String unit = 'in',
  }) {
    double u = snugUnderbust;
    double s = standingBust;
    double? l = leaningBust;
    double? y = lyingBust;
    if (unit == 'cm') {
      u /= 2.54; s /= 2.54; l = l == null ? null : l / 2.54; y = y == null ? null : y / 2.54;
    }
    final bustValues = <double>[s, if (l != null) l, if (y != null) y];
    final bust = bustValues.reduce((a, b) => a + b) / bustValues.length;
    final band = (u / 2).round() * 2;
    final diff = math.max(0, bust - band);
    const cups = <String>['AA','A','B','C','D','DD/E','DDD/F','G','H','I','J','K'];
    final cupIndex = diff.round().clamp(0, cups.length - 1).toInt();
    final cup = cups[cupIndex];
    final primary = '$band$cup';
    final alt = <String>{
      '${math.max(28, band - 2)}${cups[(cupIndex + 1).clamp(0, cups.length - 1).toInt()]}',
      primary,
      '${band + 2}${cups[(cupIndex - 1).clamp(0, cups.length - 1).toInt()]}',
    }.toList();
    final complete = 2 + (leaningBust != null ? 1 : 0) + (lyingBust != null ? 1 : 0);
    final confidence = (45 + complete * 10).clamp(45, 78).toInt();
    final quality = complete >= 4 ? 'Moderate' : 'Low';
    return BraEstimate(
      primary: 'Likely around $primary in a typical US-style sizing system',
      alternatives: alt,
      confidence: confidence,
      dataQuality: quality,
      explanation: 'The estimate uses snug underbust for a starting band and the average supplied bust measurements for cup-volume difference. Brand, country, wire width, projection, tissue distribution, and style can shift the best fit substantially.',
    );
  }

  TrendEstimate? trend(String metric, List<Map<String, dynamic>> entries) {
    final points = <Map<String, dynamic>>[];
    for (final e in entries) {
      if (e['type'] != metric) continue;
      final value = double.tryParse('${e['value']}');
      final date = DateTime.tryParse('${e['date']}');
      if (value != null && date != null) points.add({'v': value, 'd': date});
    }
    if (points.length < 2) return null;
    points.sort((a, b) => (a['d'] as DateTime).compareTo(b['d'] as DateTime));
    final first = points.first;
    final last = points.last;
    final days = math.max(1, (last['d'] as DateTime).difference(first['d'] as DateTime).inDays).toInt();
    final delta = (last['v'] as double) - (first['v'] as double);
    final monthly = delta / days * 30.4375;
    final direction = monthly.abs() < 0.01 ? 'stable' : (monthly > 0 ? 'increasing' : 'decreasing');
    final confidence = (35 + points.length * 7 + math.min(20, days ~/ 30)).clamp(35, 85).toInt();
    final quality = points.length >= 6 && days >= 90 ? 'High' : (points.length >= 3 ? 'Moderate' : 'Low');
    return TrendEstimate(
      metric: metric,
      current: last['v'] as double,
      direction: direction,
      monthlyRate: monthly,
      confidence: confidence,
      dataQuality: quality,
      limitations: 'This is a descriptive extrapolation of your own entries, not a medical prognosis or guarantee. Changes in measurement technique, clothing, hydration, posture, timing, treatment, and ordinary biological variation can materially affect the trend.',
    );
  }
}

import 'dart:convert';
import '../models/ai_models.dart';
import '../models/question.dart';
import 'secure_vault.dart';

class AiContextBuilder {
  AiContextBuilder(this.questions);
  final Map<String, List<WellnessQuestion>> questions;

  Map<String, WellnessQuestion> get _byId {
    final result = <String, WellnessQuestion>{};
    for (final list in questions.values) {
      for (final q in list) {
        result[q.id] = q;
      }
    }
    return result;
  }

  Future<String> build(SecureVault vault, AiSettings settings) async {
    final all = await vault.readAll();
    final out = <String, dynamic>{
      'context_generated_at': DateTime.now().toUtc().toIso8601String(),
      'context_notice': 'Voluntarily supplied user data. Treat as sensitive. Do not infer facts not supported by this data.',
    };

    final rawAnswers = Map<String, dynamic>.from(all['answers'] as Map? ?? const <String, dynamic>{});
    final qIndex = _byId;
    final answers = <Map<String, dynamic>>[];
    for (final entry in rawAnswers.entries) {
      final q = qIndex[entry.key];
      final value = entry.value;
      if (q == null) continue;
      final isMentalHealth = entry.key.startsWith('MH-');
      final sensitiveCategory = _sexualOrReproductive(q.category) || _sexualOrReproductive(q.question);
      if (isMentalHealth && !settings.includeSensitiveMentalHealth && !settings.fullContext) continue;
      if (sensitiveCategory && !settings.includeSexualReproductive && !settings.fullContext) continue;
      answers.add({
        'id': q.id,
        'category': q.category,
        'question': q.question,
        'answer': value,
      });
    }
    out['questionnaire_answers'] = answers;

    _copyIfPresent(out, all, 'measurements');
    _copyIfPresent(out, all, 'mental_checkins', allow: settings.includeSensitiveMentalHealth || settings.fullContext);
    _copyIfPresent(out, all, 'feature_preferences');
    _copyIfPresent(out, all, 'disabled_question_categories');
    _copyIfPresent(out, all, 'tools');
    _copyIfPresent(out, all, 'ai_memory');

    _copyIfPresent(out, all, 'journals', allow: settings.includeJournals || settings.fullContext);
    _copyIfPresent(out, all, 'contacts', allow: settings.includeContacts || settings.fullContext);
    _copyIfPresent(out, all, 'safety_plan', allow: settings.includeSafetyPlan || settings.fullContext);
    _copyIfPresent(out, all, 'companion_history', allow: settings.fullContext);
    _copyIfPresent(out, all, 'community_history', allow: settings.includeCommunityHistory || settings.fullContext);

    if ((settings.includePhotoMetadata || settings.fullContext) && all['photos'] is List) {
      out['photo_metadata'] = (all['photos'] as List).map((item) {
        if (item is! Map) return item;
        final copy = Map<String, dynamic>.from(item);
        copy.remove('path');
        copy.remove('bytes');
        return copy;
      }).toList();
    }

    return jsonEncode(out);
  }

  bool _sexualOrReproductive(String text) {
    final lower = text.toLowerCase();
    const terms = [
      'genital', 'bottom growth', 'sexual', 'libido', 'orgasm', 'erect', 'testicular',
      'menstru', 'pelvic', 'fertility', 'sperm', 'egg', 'ovary', 'uterus', 'reproductive',
      'vagin', 'phallo', 'metoidi', 'chest & breast-tissue', 'breast development',
    ];
    return terms.any(lower.contains);
  }

  void _copyIfPresent(Map<String, dynamic> out, Map<String, dynamic> all, String key, {bool allow = true}) {
    if (allow && all.containsKey(key)) out[key] = all[key];
  }
}

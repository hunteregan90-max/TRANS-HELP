import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:http/http.dart' as http;

class ApiClient {
  ApiClient({this.baseUrl = const String.fromEnvironment('API_BASE_URL', defaultValue: 'http://10.0.2.2:8000')});
  final String baseUrl;
  final _secure = const FlutterSecureStorage();
  String? _token;
  bool get isAuthenticated => _token != null && _token!.isNotEmpty;

  Future<void> restoreToken() async => _token = await _secure.read(key: 'auth_token');
  Map<String,String> get _headers => {'content-type':'application/json',if(_token!=null)'authorization':'Bearer $_token'};
  Map<String,dynamic> _decode(http.Response r){Map<String,dynamic> body={};try{final d=jsonDecode(r.body);if(d is Map)body=Map<String,dynamic>.from(d);}catch(_){body={'detail':r.body};}if(r.statusCode>=400)throw Exception(body['detail']??'Request failed (${r.statusCode})');return body;}

  Future<Map<String, dynamic>> register({required String invite, required String username, required String password, required String displayName}) async {final r=await http.post(Uri.parse('$baseUrl/auth/register'),headers:_headers,body:jsonEncode({'invite_code':invite,'username':username,'password':password,'display_name':displayName}));final body=_decode(r);_token=body['access_token'] as String;await _secure.write(key:'auth_token',value:_token);return body;}
  Future<Map<String,dynamic>> login(String username,String password)async{final r=await http.post(Uri.parse('$baseUrl/auth/login'),headers:_headers,body:jsonEncode({'username':username,'password':password}));final body=_decode(r);_token=body['access_token'] as String;await _secure.write(key:'auth_token',value:_token);return body;}
  Future<Map<String,dynamic>> me()async{final r=await http.get(Uri.parse('$baseUrl/me'),headers:_headers);return _decode(r);}
  Future<List<Map<String,dynamic>>> posts()async{final r=await http.get(Uri.parse('$baseUrl/posts'),headers:_headers);if(r.statusCode>=400)_decode(r);return List<Map<String,dynamic>>.from((jsonDecode(r.body) as List).map((e)=>Map<String,dynamic>.from(e as Map)));}
  Future<void> createPost(String body,String visibility)async{final r=await http.post(Uri.parse('$baseUrl/posts'),headers:_headers,body:jsonEncode({'body':body,'visibility':visibility}));_decode(r);}
  Future<Map<String,dynamic>> createInvite({int hours=168})async{final r=await http.post(Uri.parse('$baseUrl/admin/invites'),headers:_headers,body:jsonEncode({'hours_valid':hours}));return _decode(r);}
  Future<List<Map<String,dynamic>>> invites()async{final r=await http.get(Uri.parse('$baseUrl/admin/invites'),headers:_headers);if(r.statusCode>=400)_decode(r);return List<Map<String,dynamic>>.from((jsonDecode(r.body) as List).map((e)=>Map<String,dynamic>.from(e as Map)));}
  Future<void> logout()async{_token=null;await _secure.delete(key:'auth_token');}
}

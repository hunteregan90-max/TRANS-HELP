import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:path_provider/path_provider.dart';

class SecureVault {
  static const _keyName = 'answer_vault_key_v2';
  final _secure = const FlutterSecureStorage();
  final _cipher = AesGcm.with256bits();

  Future<SecretKey> _key() async {
    final existing = await _secure.read(key: _keyName);
    if (existing != null) return SecretKey(base64Url.decode(existing));
    final key = await _cipher.newSecretKey();
    final bytes = await key.extractBytes();
    await _secure.write(key: _keyName, value: base64UrlEncode(bytes));
    return key;
  }

  Future<File> _file() async {
    final dir = await getApplicationSupportDirectory();
    return File('${dir.path}/private_wellness.vault');
  }

  Future<Map<String, dynamic>> readAll() async {
    final file = await _file();
    if (!await file.exists()) return <String, dynamic>{};
    try {
      final payload = jsonDecode(await file.readAsString()) as Map<String, dynamic>;
      final box = SecretBox(
        base64Url.decode(payload['ciphertext'] as String),
        nonce: base64Url.decode(payload['nonce'] as String),
        mac: Mac(base64Url.decode(payload['mac'] as String)),
      );
      final clear = await _cipher.decrypt(box, secretKey: await _key());
      return Map<String, dynamic>.from(jsonDecode(utf8.decode(clear)) as Map);
    } catch (_) {
      return <String, dynamic>{};
    }
  }

  Future<void> _writeAll(Map<String, dynamic> all) async {
    final nonce = _cipher.newNonce();
    final box = await _cipher.encrypt(
      Uint8List.fromList(utf8.encode(jsonEncode(all))),
      secretKey: await _key(),
      nonce: nonce,
    );
    final file = await _file();
    await file.parent.create(recursive: true);
    await file.writeAsString(jsonEncode({
      'ciphertext': base64UrlEncode(box.cipherText),
      'nonce': base64UrlEncode(box.nonce),
      'mac': base64UrlEncode(box.mac.bytes),
    }));
  }

  Future<dynamic> readValue(String key, {dynamic fallback}) async {
    final all = await readAll();
    return all.containsKey(key) ? all[key] : fallback;
  }

  bool _isUserDataKey(String key) => !key.startsWith('ai_') &&
      key != 'last_ai_analysis_at' &&
      key != '_last_data_change_at' &&
      key != 'ui_settings';

  void _touchUserData(Map<String, dynamic> all, String key) {
    if (_isUserDataKey(key)) {
      all['_last_data_change_at'] = DateTime.now().toUtc().toIso8601String();
    }
  }

  Future<void> writeValue(String key, dynamic value) async {
    final all = await readAll();
    all[key] = value;
    _touchUserData(all, key);
    await _writeAll(all);
  }

  Future<void> appendToCollection(String key, Map<String, dynamic> value) async {
    final all = await readAll();
    final list = List<dynamic>.from(all[key] as List<dynamic>? ?? const <dynamic>[]);
    list.insert(0, value);
    all[key] = list;
    _touchUserData(all, key);
    await _writeAll(all);
  }

  Future<void> replaceCollection(String key, List<Map<String, dynamic>> values) async {
    await writeValue(key, values);
  }

  Future<void> writeAnswer(String id, dynamic value) async {
    final all = await readAll();
    final answers = Map<String, dynamic>.from(all['answers'] as Map? ?? const <String, dynamic>{});
    answers[id] = {
      'value': value,
      'updated_at': DateTime.now().toUtc().toIso8601String(),
    };
    all['answers'] = answers;
    _touchUserData(all, 'answers');
    await _writeAll(all);
  }

  Future<Map<String, dynamic>> readAnswers() async {
    final all = await readAll();
    return Map<String, dynamic>.from(all['answers'] as Map? ?? const <String, dynamic>{});
  }

  Future<String> exportDecryptedJson() async {
    final dir = await getApplicationDocumentsDirectory();
    final stamp = DateTime.now().toUtc().toIso8601String().replaceAll(':', '-');
    final file = File('${dir.path}/private_wellness_export_$stamp.json');
    await file.writeAsString(const JsonEncoder.withIndent('  ').convert(await readAll()));
    return file.path;
  }

  Future<String> exportDecryptedCsv() async {
    String cell(Object? value) {
      final text = value is String ? value : jsonEncode(value);
      return '"${text.replaceAll('"', '""')}"';
    }
    final all = await readAll();
    final rows = <String>['section,key,index,value_json'];
    for (final entry in all.entries) {
      final value = entry.value;
      if (value is List) {
        for (var i = 0; i < value.length; i++) {
          rows.add([cell(entry.key), cell('item'), '$i', cell(value[i])].join(','));
        }
      } else if (value is Map) {
        for (final nested in value.entries) {
          rows.add([cell(entry.key), cell(nested.key), '', cell(nested.value)].join(','));
        }
      } else {
        rows.add([cell(entry.key), cell('value'), '', cell(value)].join(','));
      }
    }
    final dir = await getApplicationDocumentsDirectory();
    final stamp = DateTime.now().toUtc().toIso8601String().replaceAll(':', '-');
    final file = File('${dir.path}/private_wellness_export_$stamp.csv');
    await file.writeAsString(rows.join('\n'));
    return file.path;
  }

  Future<int> itemCount(String key) async {
    final value = await readValue(key);
    if (value is List) return value.length;
    if (value is Map) return value.length;
    return value == null ? 0 : 1;
  }


  Future<String> writeEncryptedBlob(String id, Uint8List bytes) async {
    final dir = await getApplicationSupportDirectory();
    final folder = Directory('${dir.path}/private_blobs');
    await folder.create(recursive: true);
    final nonce = _cipher.newNonce();
    final box = await _cipher.encrypt(bytes, secretKey: await _key(), nonce: nonce);
    final file = File('${folder.path}/$id.blob');
    await file.writeAsString(jsonEncode({
      'ciphertext': base64UrlEncode(box.cipherText),
      'nonce': base64UrlEncode(box.nonce),
      'mac': base64UrlEncode(box.mac.bytes),
    }));
    return file.path;
  }

  Future<Uint8List?> readEncryptedBlob(String path) async {
    try {
      final file = File(path);
      if (!await file.exists()) return null;
      final payload = jsonDecode(await file.readAsString()) as Map<String, dynamic>;
      final box = SecretBox(
        base64Url.decode(payload['ciphertext'] as String),
        nonce: base64Url.decode(payload['nonce'] as String),
        mac: Mac(base64Url.decode(payload['mac'] as String)),
      );
      final clear = await _cipher.decrypt(box, secretKey: await _key());
      return Uint8List.fromList(clear);
    } catch (_) {
      return null;
    }
  }

  Future<void> clear() async {
    final file = await _file();
    if (await file.exists()) await file.delete();
    final dir = await getApplicationSupportDirectory();
    final blobs = Directory('${dir.path}/private_blobs');
    if (await blobs.exists()) await blobs.delete(recursive: true);
    await _secure.delete(key: _keyName);
  }
}

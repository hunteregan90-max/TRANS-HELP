import 'package:flutter/material.dart';
import 'models/question.dart';
import 'services/api_client.dart';
import 'services/question_repository.dart';
import 'services/secure_vault.dart';
import 'screens/enrollment_screen.dart';
import 'screens/home_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final questions = await QuestionRepository().load();
  final api = ApiClient();
  final vault = SecureVault();
  await api.restoreToken();
  final rawUi = await vault.readValue('ui_settings', fallback: const <String,dynamic>{});
  final initialUi = Map<String,dynamic>.from(rawUi as Map);
  runApp(WellnessApp(questions:questions,api:api,vault:vault,initialUi:initialUi));
}

class WellnessApp extends StatefulWidget {
  const WellnessApp({super.key,required this.questions,required this.api,required this.vault,required this.initialUi});
  final Map<String,List<WellnessQuestion>> questions;
  final ApiClient api;
  final SecureVault vault;
  final Map<String,dynamic> initialUi;
  @override State<WellnessApp> createState()=>_WellnessAppState();
}

class _WellnessAppState extends State<WellnessApp>{
 bool inside=false,preview=false;
 late Map<String,dynamic> ui;
 @override void initState(){super.initState();ui=Map<String,dynamic>.from(widget.initialUi);}
 ThemeMode get mode=>switch('${ui['theme']??'system'}'){ 'light'=>ThemeMode.light,'dark'=>ThemeMode.dark,_=>ThemeMode.system };
 double get textScale=>(ui['text_scale'] as num?)?.toDouble()??1.0;
 bool get reducedMotion=>ui['reduced_motion']==true;
 bool get lowStimulation=>ui['low_stimulation']==true;
 void applyUi(Map<String,dynamic> next)=>setState(()=>ui=Map<String,dynamic>.from(next));
 @override Widget build(BuildContext context)=>MaterialApp(
  debugShowCheckedModeBanner:false,
  title:'Private Wellness',
  themeMode:mode,
  themeAnimationDuration:(reducedMotion||lowStimulation)?Duration.zero:const Duration(milliseconds:200),
  theme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:Colors.black,brightness:Brightness.light),useMaterial3:true,inputDecorationTheme:const InputDecorationTheme(border:OutlineInputBorder())),
  darkTheme:ThemeData(colorScheme:ColorScheme.fromSeed(seedColor:Colors.white,brightness:Brightness.dark),useMaterial3:true,inputDecorationTheme:const InputDecorationTheme(border:OutlineInputBorder())),
  builder:(context,child){final mq=MediaQuery.of(context);return MediaQuery(data:mq.copyWith(textScaler:TextScaler.linear(textScale),disableAnimations:reducedMotion||lowStimulation),child:child??const SizedBox.shrink());},
  home:inside?HomeScreen(questions:widget.questions,vault:widget.vault,preview:preview,api:widget.api,onUiChanged:applyUi):EnrollmentScreen(api:widget.api,onAuthenticated:()=>setState((){inside=true;preview=false;}),onPreview:()=>setState((){inside=true;preview=true;})),
 );
}

import 'package:flutter_test/flutter_test.dart';

void main() {
  test('question-bank arithmetic', () {
    expect(750 + 750 + 750, 2250);
  });
}
